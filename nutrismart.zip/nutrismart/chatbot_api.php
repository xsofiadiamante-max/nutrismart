<?php
session_start();
header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user'])) {
    echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
    exit;
}

/** Limit text without requiring mbstring (some XAMPP builds omit it). */
function nutrismart_text_limit(string $s, int $len): string
{
    if (function_exists('mb_strlen') && function_exists('mb_substr')) {
        return mb_strlen($s) > $len ? mb_substr($s, 0, $len) : $s;
    }

    return strlen($s) > $len ? substr($s, 0, $len) : $s;
}

require_once __DIR__ . '/includes/ai_helper.php';
require_once __DIR__ . '/includes/nutrition_kb.php';

$raw = file_get_contents('php://input');
$input = $raw ? json_decode($raw, true) : null;

// Legacy GET ?msg=
if (isset($_GET['msg']) && (!is_array($input) || empty($input))) {
    $msg = strtolower(trim((string) $_GET['msg']));
    echo json_encode(['ok' => true, 'text' => nutrismart_fallback_reply($msg), 'source' => 'fallback']);
    exit;
}

if (!is_array($input)) {
    echo json_encode(['ok' => false, 'error' => 'Invalid JSON']);
    exit;
}

$messagesIn = isset($input['messages']) && is_array($input['messages']) ? $input['messages'] : null;
$single = isset($input['message']) ? trim((string) $input['message']) : '';

if ($messagesIn) {
    $clean = [];
    foreach (array_slice($messagesIn, -16) as $m) {
        if (!is_array($m) || !isset($m['role'], $m['content'])) {
            continue;
        }
        $role = $m['role'] === 'assistant' ? 'assistant' : 'user';
        $content = nutrismart_text_limit(preg_replace('/\s+/u', ' ', (string) $m['content']), 4000);
        if ($content === '') {
            continue;
        }
        $clean[] = ['role' => $role, 'content' => $content];
    }
    if (empty($clean)) {
        echo json_encode(['ok' => false, 'error' => 'No messages']);
        exit;
    }
} elseif ($single !== '') {
    $clean = [['role' => 'user', 'content' => nutrismart_text_limit($single, 4000)]];
} else {
    echo json_encode(['ok' => false, 'error' => 'Empty message']);
    exit;
}

$system = 'You are NutriSmart Live AI, a nutrition and wellness education assistant for students and staff at SEAIT (Philippines). '
    . 'Help with healthy eating habits, BMI awareness, balanced plates, Filipino meals, hydration, sleep, stress, and campus-friendly routines. '
    . 'Be warm, practical, and concise (short paragraphs or bullets). '
    . 'Never diagnose diseases, prescribe supplements/medications, or replace licensed professionals. '
    . 'For eating disorders, severe allergies, diabetes, pregnancy, or chronic illness, urge consulting a doctor or registered dietitian. '
    . 'You may give general food ideas but not strict medical meal plans.';

$apiMessages = array_merge(
    [['role' => 'system', 'content' => $system]],
    $clean
);

$ai = nutrismart_openai_chat($apiMessages, 0.7, 1200);

if ($ai['ok']) {
    echo json_encode(['ok' => true, 'text' => $ai['text'], 'source' => 'ai']);
    exit;
}

$errorNote = isset($ai['error']) ? $ai['error'] : '';

// Fallback: last user turn
$lastUser = '';
for ($i = count($clean) - 1; $i >= 0; $i--) {
    if ($clean[$i]['role'] === 'user') {
        $lastUser = strtolower($clean[$i]['content']);
        break;
    }
}
if ($lastUser === '' && $single !== '') {
    $lastUser = strtolower($single);
}

$fb = nutrismart_fallback_reply($lastUser);
echo json_encode([
    'ok' => true,
    'text' => $fb,
    'source' => 'fallback',
    'ai_error' => $errorNote ?: 'not_configured',
], JSON_UNESCAPED_UNICODE);

function nutrismart_fallback_reply(string $msg): string
{
    $short = ' Reminder: educational only—not medical advice.';

    if ($msg === '') {
        return 'Ask about BMI, Filipino meals, hydration, sleep, protein, or campus eating—or type **help** for a topic list.' . $short;
    }

    if (preg_match('/^(help|topics|guide)\b/i', trim($msg))) {
        return nutrismart_kb_default_guide() . nutrismart_kb_disclaimer();
    }

    $kb = nutrismart_kb_match($msg);
    if ($kb !== null) {
        return $kb . nutrismart_kb_disclaimer();
    }

    if (strpos($msg, 'meal plan') !== false || strpos($msg, 'planner') !== false || strpos($msg, 'bmi connect') !== false) {
        return "**Meal planner in NutriSmart**\n\nOpen **Dashboard → Meal Planner**. If your OpenAI quota allows, **Generate** builds a fresh AI day plan from your latest BMI (and age/activity if saved). Otherwise you still see **template meals** from the database by category. Update BMI when your weight changes so categories stay meaningful.\n\n"
            . "Use **BMI** first, then planner—order matters." . nutrismart_kb_disclaimer();
    }

    if (preg_match('/\b(hello|hi|hey|good\s*(morning|afternoon|evening))\b/i', $msg)) {
        return "**Hello — offline nutrition guide**\n\n"
            . "I’m running without live AI, but you can still ask detailed questions. Try words like **hydration**, **Pinoy**, **protein**, **sleep**, **exam**, **diabetes** (general info only), **budget meals**, or **BMI**. Type **help** for a full topic list.\n\n"
            . "Live AI returns when your API billing/quota is active—this guide works anytime." . nutrismart_kb_disclaimer();
    }

    if (strpos($msg, 'thank') !== false) {
        return 'You’re welcome. Keep using balanced questions—type **help** anytime for topic ideas.' . $short;
    }

    return nutrismart_kb_default_guide() . nutrismart_kb_disclaimer();
}
