<?php
/**
 * AI settings for NutriSmart. Keys load from:
 * 1) Environment: OPENAI_API_KEY, OPENAI_MODEL, OPENAI_API_BASE, OPENAI_ORGANIZATION, OPENAI_PROJECT
 * 2) ai_config.local.php (recommended on XAMPP)
 *
 * Optional local keys:
 * - ssl_verify: false  → only if HTTPS fails with SSL errors (try fixing PHP CA bundle first)
 * - cacert: 'C:/path/to/cacert.pem'  → from https://curl.se/ca/cacert.pem
 */
if (!defined('NUTRISMART_AI_CONFIG')) {
    define('NUTRISMART_AI_CONFIG', true);
}

$ns_key = trim((string) (getenv('OPENAI_API_KEY') ?: ''));
$ns_model = getenv('OPENAI_MODEL') ?: 'gpt-4o-mini';
$ns_base = getenv('OPENAI_API_BASE') ?: 'https://api.openai.com/v1';
$ns_org = trim((string) (getenv('OPENAI_ORGANIZATION') ?: ''));
$ns_project = trim((string) (getenv('OPENAI_PROJECT') ?: ''));
$ns_ssl_verify = true;
$ns_cacert = '';

$localPath = __DIR__ . '/ai_config.local.php';
if (is_readable($localPath)) {
    $local = include $localPath;
    if (is_array($local)) {
        if (!empty($local['api_key'])) {
            $ns_key = trim((string) $local['api_key']);
        }
        if (!empty($local['model'])) {
            $ns_model = (string) $local['model'];
        }
        if (!empty($local['api_base'])) {
            $ns_base = (string) $local['api_base'];
        }
        if (array_key_exists('organization', $local) && $local['organization'] !== '') {
            $ns_org = trim((string) $local['organization']);
        }
        if (array_key_exists('openai_organization', $local) && $local['openai_organization'] !== '') {
            $ns_org = trim((string) $local['openai_organization']);
        }
        if (array_key_exists('project', $local) && $local['project'] !== '') {
            $ns_project = trim((string) $local['project']);
        }
        if (array_key_exists('openai_project', $local) && $local['openai_project'] !== '') {
            $ns_project = trim((string) $local['openai_project']);
        }
        if (array_key_exists('ssl_verify', $local)) {
            $ns_ssl_verify = (bool) $local['ssl_verify'];
        }
        if (!empty($local['cacert']) && is_readable((string) $local['cacert'])) {
            $ns_cacert = (string) $local['cacert'];
        }
    }
}

define('OPENAI_API_KEY', $ns_key);
define('OPENAI_MODEL', $ns_model);
define('OPENAI_API_BASE', rtrim($ns_base, '/'));
define('OPENAI_ORGANIZATION', $ns_org);
define('OPENAI_PROJECT', $ns_project);
define('OPENAI_SSL_VERIFY', $ns_ssl_verify);
define('OPENAI_CACERT', $ns_cacert);
