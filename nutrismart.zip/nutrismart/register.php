<?php
include "db.php";

if (isset($_POST['register'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5($_POST['password']);

    $check = $conn->query("SELECT * FROM users WHERE email='$email'");

    if ($check->num_rows > 0) {
        $error = "Email already exists!";
    } else {
        $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
        if ($conn->query($sql)) {
            header("Location: login.php?registered=1");
            exit();
        }
        $error = "Registration failed: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <title>Register — NutriSmart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
</head>
<body class="ns-body ns-auth-page">
    <div class="ns-auth-blob ns-auth-blob-1" aria-hidden="true"></div>
    <div class="ns-auth-blob ns-auth-blob-2" aria-hidden="true"></div>
    <div class="container position-relative" style="z-index:1;">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">
                <div class="ns-auth-card shadow-lg">
                    <div class="ns-auth-header">
                        <i class="fas fa-user-plus fa-3x mb-3 opacity-90"></i>
                        <h2 class="h3 fw-bold mb-1" style="font-family:var(--ns-font-display);">Create account</h2>
                        <p class="mb-0 small opacity-90">PHC · NutriSmart</p>
                    </div>
                    <div class="ns-auth-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger rounded-3 border-0 small"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>

                        <form method="POST" class="ns-input-pill">
                            <div class="mb-3">
                                <label class="form-label small fw-semibold text-secondary">Full name</label>
                                <input type="text" name="name" class="form-control" placeholder="Your name" required autocomplete="name">
                            </div>
                            <div class="mb-3">
                                <label class="form-label small fw-semibold text-secondary">Email</label>
                                <input type="email" name="email" class="form-control" placeholder="you@school.edu" required autocomplete="email">
                            </div>
                            <div class="mb-4">
                                <label class="form-label small fw-semibold text-secondary">Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Choose a password" required autocomplete="new-password">
                            </div>
                            <button type="submit" name="register" class="btn ns-btn-block">
                                <i class="fas fa-user-plus me-2"></i>Create account
                            </button>
                        </form>

                        <div class="text-center mt-4 pt-2 border-top">
                            <p class="mb-2 small">Already have an account? <a href="login.php" class="fw-semibold text-decoration-none" style="color:var(--ns-teal-dark);">Log in</a></p>
                            <a href="index.php" class="small text-muted text-decoration-none"><i class="fas fa-arrow-left me-1"></i>Back to home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
