<?php
session_start();
include "db.php";
require_once __DIR__ . '/includes/bmi_schema.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

nutrismart_ensure_bmi_columns($conn);

$email = $_SESSION['user'];
$email_esc = $conn->real_escape_string($email);
$user_res = $conn->query("SELECT name FROM users WHERE email='$email_esc' LIMIT 1");
$user = $user_res ? $user_res->fetch_assoc() : null;
if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}
$records = $conn->query("SELECT * FROM bmi_records WHERE user_email='$email_esc' ORDER BY id DESC");

function nutrismart_bmi_row_ts(array $row): int
{
    if (!empty($row['recorded_at'])) {
        return strtotime($row['recorded_at']);
    }
    if (!empty($row['created_at'])) {
        return strtotime($row['created_at']);
    }
    return time();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <title>BMI History - NutriSmart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 30px;
        }
        
        .table {
            border-radius: 15px;
            overflow: hidden;
        }
        
        .table thead {
            background: var(--ns-gradient);
            color: white;
        }
        
        .badge-category {
            padding: 5px 15px;
            border-radius: 50px;
            font-weight: normal;
        }
    </style>
</head>
<body class="ns-body ns-page-app ns-overlay-dark">
    <?php $ns_nav_active = 'bmi'; include __DIR__ . '/includes/app_nav.php'; ?>
    <div class="container pb-5 ns-z-main">
        <div class="ns-app-card">
            <div class="ns-app-card-header">
                <i class="fas fa-chart-line fa-3x mb-3"></i>
                <h2 class="mb-1">BMI history</h2>
                <p class="mb-0 small opacity-90">Saved readings for NutriSmart · screening trend only</p>
            </div>
            <div class="ns-app-card-body">
                <?php if ($records && $records->num_rows > 0): ?>
                    <?php
                    $dates = [];
                    $bmi_values = [];
                    $categories = [];
                    
                    $records->data_seek(0);
                    while ($row = $records->fetch_assoc()) {
                        $dates[] = date('M d', nutrismart_bmi_row_ts($row));
                        $bmi_values[] = round($row['bmi'], 1);
                        $categories[] = $row['category'];
                    }
                    ?>
                    
                    <!-- Chart -->
                    <div class="chart-container">
                        <canvas id="bmiChart"></canvas>
                    </div>
                    
                    <script>
                        const ctx = document.getElementById('bmiChart').getContext('2d');
                        new Chart(ctx, {
                            type: 'line',
                            data: {
                                labels: <?php echo json_encode(array_reverse($dates)); ?>,
                                datasets: [{
                                    label: 'BMI Value',
                                    data: <?php echo json_encode(array_reverse($bmi_values)); ?>,
                                    borderColor: '#0d9488',
                                    backgroundColor: 'rgba(13, 148, 136, 0.12)',
                                    borderWidth: 3,
                                    tension: 0.4,
                                    fill: true,
                                    pointBackgroundColor: '#047857',
                                    pointBorderColor: '#fff',
                                    pointBorderWidth: 2,
                                    pointRadius: 6
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        display: false
                                    }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: false,
                                        grid: {
                                            color: 'rgba(0,0,0,0.05)'
                                        }
                                    },
                                    x: {
                                        grid: {
                                            display: false
                                        }
                                    }
                                }
                            }
                        });
                    </script>
                    
                    <!-- History Table -->
                    <h4 class="mb-3">Previous Records</h4>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Age</th>
                                    <th>Weight (kg)</th>
                                    <th>Height (cm)</th>
                                    <th>BMI</th>
                                    <th>Category</th>
                                    <th>Activity</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $records->data_seek(0);
                                while($row = $records->fetch_assoc()): 
                                ?>
                                <tr>
                                    <td><?php echo date('M d, Y', nutrismart_bmi_row_ts($row)); ?></td>
                                    <td><?php echo isset($row['age']) && $row['age'] !== null ? (int) $row['age'] : '—'; ?></td>
                                    <td><?php echo htmlspecialchars((string) $row['weight']); ?></td>
                                    <td><?php echo htmlspecialchars((string) $row['height']); ?></td>
                                    <td><strong><?php echo number_format($row['bmi'], 1); ?></strong></td>
                                    <td>
                                        <span class="badge-category" style="background: <?php 
                                            if($row['category'] == 'Underweight') echo '#ffc107';
                                            elseif($row['category'] == 'Normal') echo '#28a745';
                                            elseif($row['category'] == 'Overweight') echo '#fd7e14';
                                            else echo '#dc3545';
                                        ?>; color: white;">
                                            <?php echo htmlspecialchars($row['category']); ?>
                                        </span>
                                    </td>
                                    <td><small><?php echo isset($row['activity_level']) && $row['activity_level'] !== '' ? htmlspecialchars($row['activity_level']) : '—'; ?></small></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-chart-line fa-4x text-muted mb-3"></i>
                        <h4>No BMI Records Yet</h4>
                        <p class="text-muted">Calculate your BMI to start tracking your progress</p>
                        <a href="bmi.php" class="btn btn-primary">
                            <i class="fas fa-calculator me-2"></i>Calculate BMI
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>