<?php
session_start();
header('Content-Type: application/json; charset=UTF-8');

if (!isset($_SESSION['user'])) {
    echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
    exit;
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/includes/bmi_schema.php';
require_once __DIR__ . '/includes/ai_helper.php';

nutrismart_ensure_bmi_columns($conn);

$email_esc = $conn->real_escape_string($_SESSION['user']);

$sql = "SELECT weight, height, bmi, category, age, sex, activity_level 
        FROM bmi_records WHERE user_email='$email_esc' ORDER BY id DESC LIMIT 1";
$res = $conn->query($sql);
$row = $res ? $res->fetch_assoc() : null;

if (!$row) {
    echo json_encode(['ok' => false, 'error' => 'No BMI record. Calculate BMI first.', 'code' => 'no_bmi']);
    exit;
}

$w = (float) $row['weight'];
$h = (float) $row['height'];
$bmi = (float) $row['bmi'];
$cat = $row['category'];
$age = isset($row['age']) && $row['age'] !== null ? (int) $row['age'] : null;
$sex = isset($row['sex']) ? $row['sex'] : '';
$act = isset($row['activity_level']) ? $row['activity_level'] : '';

$profile = "User profile (educational meal ideas only, not medical advice):\n";
$profile .= "- BMI: " . round($bmi, 1) . " (category: {$cat})\n";
$profile .= "- Weight: {$w} kg, Height: {$h} cm\n";
if ($age !== null) {
    $profile .= "- Age: {$age}\n";
}
if ($sex !== '') {
    $profile .= "- Sex: {$sex}\n";
}
if ($act !== '') {
    $profile .= "- Usual activity level: {$act}\n";
}

$system = 'You are NutriSmart, an AI nutrition education assistant for students and staff at SEAIT (Philippines). '
    . 'Suggest ONE full day of meals: Breakfast, Lunch, Dinner, and one Snack. '
    . 'Tailor energy and food choices to the user\'s BMI category (e.g. nutrient-dense options for underweight; '
    . 'portion-aware, fiber-rich, lower added-sugar options for overweight/obese as appropriate). '
    . 'Include Filipino-friendly dishes where suitable. For each meal list foods with approximate kcal per item and a total per meal. '
    . 'End with estimated daily total kcal range. '
    . 'Clearly state this is general education, not a prescription. '
    . 'Use clear headings and bullet lists. No diagnosis.';

$userMsg = $profile . "\nGenerate fresh suggestions now. Vary proteins and vegetables.";

$messages = [
    ['role' => 'system', 'content' => $system],
    ['role' => 'user', 'content' => $userMsg],
];

$ai = nutrismart_openai_chat($messages, 0.75, 2200);

if ($ai['ok']) {
    echo json_encode(['ok' => true, 'text' => $ai['text'], 'source' => 'ai']);
    exit;
}

// Fallback when API missing or failed
$fallback = nutrismart_meal_fallback_text($cat);
echo json_encode([
    'ok' => true,
    'text' => $fallback . "\n\n_(AI service unavailable—showing template suggestions. Add OPENAI_API_KEY in ai_config.php for live AI.)_",
    'source' => 'fallback',
    'ai_error' => $ai['error'] ?? 'not_configured',
]);

function nutrismart_meal_fallback_text(string $category): string
{
    $c = strtolower($category);
    $base = "## Template day (non-AI)\n\n";
    if (strpos($c, 'under') !== false) {
        return $base . "**Breakfast:** Oats with milk + banana + peanut butter (~450 kcal)\n**Lunch:** Rice + grilled chicken + pinakbet + fruit (~650 kcal)\n**Dinner:** Tinola with rice + boiled egg (~550 kcal)\n**Snack:** Greek yogurt + mango (~200 kcal)\n**Approx. total:** ~1850 kcal — emphasize nutrient-dense foods and healthy fats.";
    }
    if (strpos($c, 'normal') !== false) {
        return $base . "**Breakfast:** Whole wheat bread + egg + tomato (~350 kcal)\n**Lunch:** Rice (moderate) + fish + monggo with malunggay (~600 kcal)\n**Dinner:** Ginisang gulay + tofu + small rice (~450 kcal)\n**Snack:** Apple + nuts (~200 kcal)\n**Approx. total:** ~1600 kcal — balanced plate, plenty of vegetables.";
    }
    return $base . "**Breakfast:** High-fiber cereal + milk + berries (~300 kcal)\n**Lunch:** Large salad + grilled fish + small rice (~500 kcal)\n**Dinner:** Sinigang na isda + vegetables + controlled rice (~450 kcal)\n**Snack:** Cucumber + boiled egg (~150 kcal)\n**Approx. total:** ~1400 kcal — focus on vegetables, lean protein, mindful portions.";
}
