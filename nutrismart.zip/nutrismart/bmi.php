<?php
session_start();
include "db.php";
require_once __DIR__ . '/includes/bmi_schema.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['user'];
$email_esc = $conn->real_escape_string($email);
$user_res = $conn->query("SELECT name FROM users WHERE email='$email_esc' LIMIT 1");
$user = $user_res ? $user_res->fetch_assoc() : null;
if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}
nutrismart_ensure_bmi_columns($conn);

$bmr_display = null;
$healthy_range = null;

if (isset($_POST['calculate'])) {
    $weight = (float) $_POST['weight'];
    $height = (float) $_POST['height'];
    $age = isset($_POST['age']) ? (int) $_POST['age'] : 0;
    $sex = isset($_POST['sex']) ? trim((string) $_POST['sex']) : '';
    $activity = isset($_POST['activity_level']) ? trim((string) $_POST['activity_level']) : '';

    if ($age < 10 || $age > 120) {
        $age = 0;
    }

    $height_m = $height / 100;
    $bmi = $weight / ($height_m * $height_m);

    if ($bmi < 18.5) {
        $category = "Underweight";
    } elseif ($bmi < 25) {
        $category = "Normal";
    } elseif ($bmi < 30) {
        $category = "Overweight";
    } else {
        $category = "Obese";
    }

    $sex_esc = $conn->real_escape_string($sex);
    $act_esc = $conn->real_escape_string($activity);
    $age_sql = $age > 0 ? (string) (int) $age : 'NULL';

    $conn->query("INSERT INTO bmi_records (user_email, weight, height, bmi, category, age, sex, activity_level) 
                  VALUES ('$email_esc', '$weight', '$height', '$bmi', '$category', $age_sql, " .
        ($sex !== '' ? "'$sex_esc'" : 'NULL') . ", " .
        ($activity !== '' ? "'$act_esc'" : 'NULL') . ")");

    $show_result = true;

    $h_m = $height / 100;
    $w_min = 18.5 * $h_m * $h_m;
    $w_max = 24.9 * $h_m * $h_m;
    $healthy_range = [round($w_min, 1), round($w_max, 1)];

    if ($age > 0 && ($sex === 'male' || $sex === 'female')) {
        if ($sex === 'male') {
            $bmr_display = round(10 * $weight + 6.25 * $height - 5 * $age + 5);
        } else {
            $bmr_display = round(10 * $weight + 6.25 * $height - 5 * $age - 161);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <title>BMI Calculator - NutriSmart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
    <style>
        .form-control, .form-select {
            border-radius: 50px;
            padding: 12px 20px;
            border: 2px solid #e0e0e0;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--ns-teal);
            box-shadow: none;
        }
        
        .btn-calculate {
            background: var(--ns-gradient);
            color: white;
            border-radius: 50px;
            padding: 15px;
            font-weight: bold;
            border: none;
            width: 100%;
            font-size: 1.1rem;
            transition: all 0.3s;
        }
        
        .btn-calculate:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(13, 148, 136, 0.35);
        }
        
        .result-card {
            background: linear-gradient(135deg, #f6f9fc 0%, #e6f0f9 100%);
            border-radius: 20px;
            padding: 30px;
            margin-top: 30px;
            text-align: center;
            border: 2px solid var(--ns-teal);
        }
        
        .bmi-value {
            font-size: 4rem;
            font-weight: bold;
            background: var(--ns-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            line-height: 1;
        }
        
        .category-badge {
            display: inline-block;
            padding: 10px 30px;
            border-radius: 50px;
            font-weight: bold;
            font-size: 1.2rem;
            margin-top: 15px;
        }
        
        .category-Underweight { background: #ffc107; color: #000; }
        .category-Normal { background: #28a745; color: #fff; }
        .category-Overweight { background: #fd7e14; color: #fff; }
        .category-Obese { background: #dc3545; color: #fff; }
        
        .info-box {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 15px;
            margin-top: 20px;
            text-align: left;
        }
    </style>
</head>
<body class="ns-body ns-page-app ns-overlay-dark">
    <?php $ns_nav_active = 'bmi'; include __DIR__ . '/includes/app_nav.php'; ?>
    <div class="container pb-5 ns-z-main">
        <div class="row justify-content-center">
            <div class="col-lg-7">
                <div class="ns-app-card">
                    <div class="ns-app-card-header">
                        <i class="fas fa-calculator fa-3x mb-3"></i>
                        <h2>Body Mass Index (BMI)</h2>
                        <p class="mb-0 small opacity-90">Height &amp; weight · optional age &amp; activity for BMR estimate &amp; AI meal context</p>
                    </div>
                    <div class="ns-app-card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold">Weight (kg)</label>
                                    <input type="number" step="0.1" name="weight" class="form-control" placeholder="e.g. 62.5" required
                                        value="<?php echo isset($_POST['weight']) ? htmlspecialchars((string) $_POST['weight'], ENT_QUOTES, 'UTF-8') : ''; ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label fw-bold">Height (cm)</label>
                                    <input type="number" step="0.1" name="height" class="form-control" placeholder="e.g. 168" required
                                        value="<?php echo isset($_POST['height']) ? htmlspecialchars((string) $_POST['height'], ENT_QUOTES, 'UTF-8') : ''; ?>">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-bold">Age (years)</label>
                                    <input type="number" name="age" class="form-control" placeholder="e.g. 20" min="10" max="120"
                                        value="<?php echo isset($_POST['age']) ? htmlspecialchars((string) $_POST['age'], ENT_QUOTES, 'UTF-8') : ''; ?>">
                                    <small class="text-muted">Optional — improves BMR &amp; AI suggestions</small>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-bold">Sex (for BMR)</label>
                                    <select name="sex" class="form-select">
                                        <option value="">Prefer not to say</option>
                                        <option value="female" <?php echo (isset($_POST['sex']) && $_POST['sex'] === 'female') ? 'selected' : ''; ?>>Female</option>
                                        <option value="male" <?php echo (isset($_POST['sex']) && $_POST['sex'] === 'male') ? 'selected' : ''; ?>>Male</option>
                                        <option value="other" <?php echo (isset($_POST['sex']) && $_POST['sex'] === 'other') ? 'selected' : ''; ?>>Other</option>
                                    </select>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label fw-bold">Activity level</label>
                                    <select name="activity_level" class="form-select">
                                        <option value="">Select…</option>
                                        <option value="sedentary" <?php echo (isset($_POST['activity_level']) && $_POST['activity_level'] === 'sedentary') ? 'selected' : ''; ?>>Mostly sitting</option>
                                        <option value="light" <?php echo (isset($_POST['activity_level']) && $_POST['activity_level'] === 'light') ? 'selected' : ''; ?>>Light (walks, some PE)</option>
                                        <option value="moderate" <?php echo (isset($_POST['activity_level']) && $_POST['activity_level'] === 'moderate') ? 'selected' : ''; ?>>Moderate exercise</option>
                                        <option value="active" <?php echo (isset($_POST['activity_level']) && $_POST['activity_level'] === 'active') ? 'selected' : ''; ?>>Active most days</option>
                                        <option value="very_active" <?php echo (isset($_POST['activity_level']) && $_POST['activity_level'] === 'very_active') ? 'selected' : ''; ?>>Very active / sports</option>
                                    </select>
                                </div>
                            </div>
                            
                            <button type="submit" name="calculate" class="btn-calculate">
                                <i class="fas fa-calculator me-2"></i>Calculate BMI &amp; save
                            </button>
                        </form>
                        
                        <?php if (isset($show_result)): ?>
                        <div class="result-card">
                            <h4 class="mb-4">Your result</h4>
                            <div class="bmi-value"><?php echo number_format($bmi, 1); ?></div>
                            <div class="category-badge category-<?php echo htmlspecialchars($category, ENT_QUOTES, 'UTF-8'); ?>">
                                <?php echo htmlspecialchars($category, ENT_QUOTES, 'UTF-8'); ?>
                            </div>
                            
                            <p class="small text-muted mt-3 mb-0 text-center">BMI screens weight-for-height; it does not measure body fat directly. Athletes may differ—see a professional if unsure.</p>

                            <?php if ($healthy_range): ?>
                            <div class="info-box mt-3">
                                <h6><i class="fas fa-scale-balanced me-1"></i>Healthy weight range for your height (BMI 18.5–24.9)</h6>
                                <p class="mb-0">Approximately <strong><?php echo $healthy_range[0]; ?> – <?php echo $healthy_range[1]; ?> kg</strong> (reference only).</p>
                            </div>
                            <?php endif; ?>

                            <?php if ($bmr_display !== null): ?>
                            <div class="info-box mt-3">
                                <h6><i class="fas fa-fire-flame-curved me-1"></i>Estimated BMR (Mifflin–St Jeor)</h6>
                                <p class="mb-0">About <strong><?php echo (int) $bmr_display; ?> kcal/day</strong> at rest—used for context, not a strict calorie target. Full energy needs depend on activity.</p>
                            </div>
                            <?php elseif (!empty($_POST['age']) && (int) $_POST['age'] > 0): ?>
                            <div class="info-box mt-3">
                                <p class="small mb-0 text-muted">Choose <strong>male</strong> or <strong>female</strong> above for a BMR estimate (formula differs). “Other” skips BMR to avoid mislabeling.</p>
                            </div>
                            <?php endif; ?>

                            <div class="info-box text-start mt-4">
                                <h6>BMI categories (WHO-style)</h6>
                                <ul class="list-unstyled small mb-0">
                                    <li><span class="badge bg-warning me-2">Underweight</span> Below 18.5</li>
                                    <li><span class="badge bg-success me-2">Normal</span> 18.5 – 24.9</li>
                                    <li><span class="badge text-bg-warning me-2">Overweight</span> 25 – 29.9</li>
                                    <li><span class="badge bg-danger me-2">Obese</span> 30 or more</li>
                                </ul>
                            </div>
                            
                            <div class="mt-4 d-flex flex-wrap gap-2 justify-content-center">
                                <a href="bmi_history.php" class="btn btn-outline-primary">
                                    <i class="fas fa-history me-2"></i>View history
                                </a>
                                <a href="meal_planner.php" class="btn btn-success">
                                    <i class="fas fa-wand-magic-sparkles me-2"></i>Live AI meal plan
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
