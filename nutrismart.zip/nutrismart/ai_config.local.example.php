<?php
/**
 * Copy to ai_config.local.php (never commit that file).
 */
return [
    'api_key' => '', // trim spaces; no quotes issues
    'model' => 'gpt-4o-mini',
    'api_base' => 'https://api.openai.com/v1',

    // Optional — if your org requires them (platform.openai.com)
    // 'openai_organization' => 'org-...',
    // 'openai_project' => 'proj_...',

    // Only if HTTPS fails on XAMPP (SSL certificate problem):
    // 'ssl_verify' => false,
    // Or download https://curl.se/ca/cacert.pem and set:
    // 'cacert' => 'C:/xampp/php/extras/ssl/cacert.pem',
];
