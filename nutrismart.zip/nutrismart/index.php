<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <meta name="description" content="NutriSmart — BMI, AI meal ideas, and nutrition awareness for dietary patient and staff.">
    <title>NutriSmart — AI-Based Nutrition &amp; Food Awareness (PHC)</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
    <style>
        .hero-wrap {
            min-height: 100vh;
            background: url('https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80') no-repeat center center fixed;
            background-size: cover;
        }
        .feature-tile {
            transition: transform 0.25s ease, border-color 0.25s ease, background 0.25s ease;
        }
        .feature-tile:hover {
            transform: translateY(-6px);
            border-color: rgba(13, 148, 136, 0.45) !important;
            background: rgba(255, 255, 255, 0.18) !important;
        }
        .objective-list li {
            margin-bottom: 0.5rem;
            padding-left: 0.25rem;
        }
    </style>
</head>
<body class="ns-body hero-wrap ns-overlay-dark">
    <nav class="navbar navbar-expand-lg navbar-light fixed-top ns-navbar ns-z-main">
        <div class="container">
            <a class="navbar-brand ns-brand d-flex align-items-center gap-2" href="index.php">
                <i class="fas fa-seedling ns-brand-leaf"></i>
                <span class="ns-brand-text"><span class="ns-nutri">Nutri</span><span class="ns-smart">Smart</span></span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <li class="nav-item"><a class="nav-link" href="#features">What you can do</a></li>
                    <li class="nav-item"><a class="nav-link" href="#about">About ealthcare Center</a></li>
                    <li class="nav-item"><a class="nav-link" href="#how">How it works</a></li>
                    <li class="nav-item"><a class="nav-link" href="#scope">Scope</a></li>
                    <?php if (isset($_SESSION['user'])): ?>
                        <li class="nav-item ms-lg-2">
                            <a href="dashboard.php" class="btn ns-btn-primary btn-sm"><i class="fas fa-gauge-high me-1"></i> Dashboard</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item ms-lg-2">
                            <a href="login.php" class="btn btn-outline-secondary btn-sm rounded-pill me-2">Log in</a>
                            <a href="register.php" class="btn ns-btn-primary btn-sm">Create account</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <header class="ns-z-main pt-5">
        <div class="container py-5">
            <div class="row align-items-center min-vh-100 py-lg-4">
                <div class="col-lg-6 text-white pt-5 mt-3">
                    
                    <h1 class="display-4 ns-hero-title mt-3 mb-4">
                        Smarter eating starts with <span class="text-info" style="text-shadow:0 0 40px rgba(45,212,191,0.5);">understanding</span> your nutrition
                    </h1>
                    <p class="lead opacity-90 mb-4">
                        <strong>NutriSmart</strong> is a web-based, AI-assisted nutrition awareness system for Polomolok Healthcare Center dietary patient, faculty, and staff. 
                        It classifies BMI, suggests calorie-appropriate meals, and explains basic nutrients—so everyday food choices feel clearer, not overwhelming.
                    </p>
                    <div class="d-flex flex-wrap gap-2 mb-3">
                        <?php if (!isset($_SESSION['user'])): ?>
                            <a href="register.php" class="btn ns-btn-primary btn-lg"><i class="fas fa-user-plus me-2"></i>Register for free</a>
                        <?php else: ?>
                            <a href="dashboard.php" class="btn ns-btn-primary btn-lg"><i class="fas fa-arrow-right me-2"></i>Open your dashboard</a>
                        <?php endif; ?>
                        <a href="#features" class="btn ns-btn-outline-light btn-lg">Explore features</a>
                    </div>
                    <p class="small opacity-75 mb-0">
                        Not a substitute for medical advice—built for education, habit-building, and campus wellness.
                    </p>
                </div>

            </div>
        </div>
    </header>

    <section id="features" class="py-5 ns-section-muted ns-z-main">
        <div class="container py-4">
            <div class="text-center text-white mb-5">
                <h2 class="fw-bold">Designed around your thesis scope</h2>
                <p class="mb-0 opacity-90 mx-auto" style="max-width:640px;">
                    Every module supports the same story: measure BMI → see tailored meal ideas → learn what those meals mean for energy and nutrients.
                </p>
            </div>
            <div class="row g-4">
                <div class="col-md-6 col-lg-4">
                    <div class="feature-tile ns-glass text-white h-100 p-4 border border-light border-opacity-25">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:52px;height:52px;background:var(--ns-gradient);">
                            <i class="fas fa-user-plus fa-lg"></i>
                        </div>
                        <h3 class="h5 fw-semibold">Accounts &amp; profiles</h3>
                        <p class="small opacity-90 mb-0">Simple registration so each person has a private space for BMI logs and meal guidance.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-tile ns-glass text-white h-100 p-4 border border-light border-opacity-25">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:52px;height:52px;background:var(--ns-gradient);">
                            <i class="fas fa-ruler-vertical fa-lg"></i>
                        </div>
                        <h3 class="h5 fw-semibold">BMI &amp; categories</h3>
                        <p class="small opacity-90 mb-0">Height and weight compute BMI instantly—underweight, normal, overweight, or obese—using standard cutoffs.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-tile ns-glass text-white h-100 p-4 border border-light border-opacity-25">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:52px;height:52px;background:var(--ns-gradient);">
                            <i class="fas fa-utensils fa-lg"></i>
                        </div>
                        <h3 class="h5 fw-semibold">BMI-aware meal ideas</h3>
                        <p class="small opacity-90 mb-0">Meal planner pulls suggestions matched to your latest BMI category—lighter patterns when appropriate, nourishing options when you need more density.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-tile ns-glass text-white h-100 p-4 border border-light border-opacity-25">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:52px;height:52px;background:var(--ns-gradient);">
                            <i class="fas fa-chart-pie fa-lg"></i>
                        </div>
                        <h3 class="h5 fw-semibold">Nutrition snapshots</h3>
                        <p class="small opacity-90 mb-0">See calories and meal breakdowns in plain language to connect numbers with real plates.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-tile ns-glass text-white h-100 p-4 border border-light border-opacity-25">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:52px;height:52px;background:var(--ns-gradient);">
                            <i class="fas fa-robot fa-lg"></i>
                        </div>
                        <h3 class="h5 fw-semibold">AI nutrition chat</h3>
                        <p class="small opacity-90 mb-0">Ask about BMI, meals, hydration, and habits—quick, conversational support alongside the structured tools.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4">
                    <div class="feature-tile ns-glass text-white h-100 p-4 border border-light border-opacity-25">
                        <div class="rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width:52px;height:52px;background:var(--ns-gradient);">
                            <i class="fas fa-fire-flame-curved fa-lg"></i>
                        </div>
                        <h3 class="h5 fw-semibold">Optional calorie log</h3>
                        <p class="small opacity-90 mb-0">A simple manual log for awareness—type what you ate and approximate energy. No camera scanning; you stay in control of entries.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="how" class="py-5 ns-z-main bg-white">
        <div class="container py-4">
            <div class="text-center mb-5">
                <p class="ns-eyebrow mb-2">Workflow</p>
                <h2 class="fw-bold display-6" style="font-family:var(--ns-font-display);">How it works — six steps</h2>
                <p class="text-secondary mx-auto mb-0" style="max-width:560px;">From account to daily habits: each piece connects so BMI, meals, and learning stay in sync.</p>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-10">
                    <div class="ns-card-solid p-4 p-md-5">
                        <div class="ns-timeline-step">
                            <span class="ns-step-dot">1</span>
                            <h3 class="h6 fw-bold" style="font-family:var(--ns-font-display);">Create your account</h3>
                            <p class="small text-secondary mb-0">Register with your name and email. One profile keeps BMI history and calorie logs private to you.</p>
                        </div>
                        <div class="ns-timeline-step">
                            <span class="ns-step-dot">2</span>
                            <h3 class="h6 fw-bold" style="font-family:var(--ns-font-display);">Measure BMI</h3>
                            <p class="small text-secondary mb-0">Enter height, weight, and optional age and activity. Get category bands and a healthy weight range for your height.</p>
                        </div>
                        <div class="ns-timeline-step">
                            <span class="ns-step-dot">3</span>
                            <h3 class="h6 fw-bold" style="font-family:var(--ns-font-display);">Review history</h3>
                            <p class="small text-secondary mb-0">Track changes over time with the chart—useful for thesis documentation and personal awareness.</p>
                        </div>
                        <div class="ns-timeline-step">
                            <span class="ns-step-dot">4</span>
                            <h3 class="h6 fw-bold" style="font-family:var(--ns-font-display);">Plan meals</h3>
                            <p class="small text-secondary mb-0">Open the meal planner for AI-generated day ideas (when API is active) or structured templates by BMI category.</p>
                        </div>
                        <div class="ns-timeline-step">
                            <span class="ns-step-dot">5</span>
                            <h3 class="h6 fw-bold" style="font-family:var(--ns-font-display);">Chat &amp; learn</h3>
                            <p class="small text-secondary mb-0">Ask the assistant about Filipino meals, hydration, sleep, or type <strong>help</strong> for a rich offline guide.</p>
                        </div>
                        <div class="ns-timeline-step mb-0 pb-0">
                            <span class="ns-step-dot">6</span>
                            <h3 class="h6 fw-bold" style="font-family:var(--ns-font-display);">Log calories (optional)</h3>
                            <p class="small text-secondary mb-0">Add single items or batch-select foods to see today’s total vs a simple reference goal.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="about" class="py-5 bg-light ns-z-main">
        <div class="container py-4">
            <div class="row g-4 align-items-start">
                <div class="col-lg-6">
                    <h2 class="fw-bold mb-3">Why NutriSmart fits Healthcare Center</h2>
                    <p class="text-secondary">
                        Busy classes and deadlines often push dietary patient toward quick meals. NutriSmart turns your thesis goals into a friendly workflow:
                        know your BMI category, preview meals that fit, and read short nutrient context—so “healthy” feels actionable, not abstract.
                    </p>
                    <p class="text-secondary mb-0">
                        <strong>General objective:</strong> improve nutritional awareness and habits at PHC through personalized analysis, healthier alternatives, and bite-sized food education powered by AI-assisted guidance.
                    </p>
                </div>
                <div class="col-lg-6">
                    <div class="ns-card-solid p-4 h-100">
                        <h3 class="h5 fw-semibold mb-3"><i class="fas fa-bullseye text-success me-2"></i>Specific objectives (from your study)</h3>
                        <ul class="objective-list small text-secondary ps-3 mb-0">
                            <li>Web system that classifies users by BMI.</li>
                            <li>Automatic BMI bands: underweight, normal, overweight, obese.</li>
                            <li>AI-oriented meal recommendations aligned to BMI (e.g. lower-calorie emphasis vs. nutrient-dense support).</li>
                            <li>Clear calories and essential nutrient context for suggested meals.</li>
                            <li>Promote awareness for students, faculty, and staff via accessible digital guidance.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="scope" class="py-5 ns-z-main">
        <div class="container">
            <div class="ns-card-solid p-4 p-md-5">
                <div class="row g-4">
                    <div class="col-md-6">
                        <h2 class="h4 fw-bold mb-3"><i class="fas fa-check-circle text-success me-2"></i>In scope</h2>
                        <ul class="small text-secondary mb-0">
                            <li>Registration and basic profile use</li>
                            <li>BMI calculation and standard classification</li>
                            <li>Meal recommendations tied to BMI category</li>
                            <li>Nutritional information display for those meals</li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h2 class="h4 fw-bold mb-3"><i class="fas fa-triangle-exclamation text-warning me-2"></i>Limitations (honest labeling)</h2>
                        <ul class="small text-secondary mb-0">
                            <li>Not for diagnosis or replacing doctors or dietitians</li>
                            <li>No chronic disease, allergy, or activity-level medical modeling</li>
                            <li>Web only—no standalone mobile app in this version</li>
                            <li>No photo-based food scanning or wearable integration</li>
                        </ul>
                        <p class="ns-disclaimer mb-0">Use NutriSmart as a learning companion. For medical nutrition therapy, consult a licensed professional.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer class="ns-footer text-white py-5 ns-z-main">
        <div class="container">
            <div class="row g-4 align-items-center text-center text-md-start">
                <div class="col-md-6">
                    <p class="mb-1 fw-bold" style="font-family:var(--ns-font-display);">NutriSmart</p>
                    <p class="text-white-50 small mb-0">AI-assisted nutrition awareness for PHC · BMI, meals, chat &amp; calorie log.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <a href="#how" class="text-white-50 small text-decoration-none me-3">How it works</a>
                    <a href="#scope" class="text-white-50 small text-decoration-none">Scope</a>
                </div>
            </div>
            <hr class="border-secondary opacity-25 my-4">
            <p class="text-center small text-white-50 mb-0">&copy; <?php echo date('Y'); ?> Healthcare Center · Polomolok, South Cotabato</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
