<?php
// db.php
$host = "localhost";
$user = "root";
$pass = "";  // Leave empty for XAMPP, for WAMP it's usually "root"
$db = "nutrismart";

$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to UTF-8
$conn->set_charset("utf8");

// For debugging - remove after testing
// echo "Database connected successfully!";
?>