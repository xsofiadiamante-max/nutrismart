<?php
/**
 * Shared top navigation for logged-in app pages.
 * Expects: $conn (mysqli), $_SESSION['user']. Optional: $user['name'], $ns_nav_active (home|dashboard|bmi|meals|chat|calories).
 */
if (!isset($conn) || !isset($_SESSION['user'])) {
    return;
}
$ns_nav_active = isset($ns_nav_active) ? (string) $ns_nav_active : '';
if (!isset($nav_user_name)) {
    if (isset($user['name'])) {
        $nav_user_name = $user['name'];
    } else {
        $em = $conn->real_escape_string($_SESSION['user']);
        $ur = $conn->query("SELECT name FROM users WHERE email='$em' LIMIT 1");
        $nav_user_name = ($ur && ($r = $ur->fetch_assoc())) ? $r['name'] : 'User';
    }
}
$nsNavClass = static function (string $key) use ($ns_nav_active): string {
    return $ns_nav_active === $key ? 'nav-link fw-semibold text-success' : 'nav-link';
};
?>
<nav class="navbar navbar-expand-lg navbar-light ns-navbar ns-z-main mb-2">
    <div class="container">
        <a class="navbar-brand ns-brand d-flex align-items-center gap-2" href="dashboard.php">
            <i class="fas fa-seedling ns-brand-leaf fs-4"></i>
            <span class="ns-brand-text"><span class="ns-nutri">Nutri</span><span class="ns-smart">Smart</span></span>
        </a>
        <button class="navbar-toggler rounded-pill border-0 shadow-sm" type="button" data-bs-toggle="collapse" data-bs-target="#appMainNav" aria-controls="appMainNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="appMainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-1">
                <li class="nav-item"><a class="<?php echo $nsNavClass('home'); ?>" href="index.php"><i class="fas fa-house me-1 opacity-75"></i>Home</a></li>
                <li class="nav-item"><a class="<?php echo $nsNavClass('dashboard'); ?>" href="dashboard.php"><i class="fas fa-gauge-high me-1 opacity-75"></i>Dashboard</a></li>
                <li class="nav-item"><a class="<?php echo $nsNavClass('bmi'); ?>" href="bmi.php"><i class="fas fa-ruler-vertical me-1 opacity-75"></i>BMI</a></li>
                <li class="nav-item"><a class="<?php echo $nsNavClass('meals'); ?>" href="meal_planner.php"><i class="fas fa-utensils me-1 opacity-75"></i>Meals</a></li>
                <li class="nav-item"><a class="<?php echo $nsNavClass('chat'); ?>" href="chatbot.php"><i class="fas fa-comments me-1 opacity-75"></i>Chat</a></li>
                <li class="nav-item"><a class="<?php echo $nsNavClass('calories'); ?>" href="calorie_tracker.php"><i class="fas fa-fire me-1 opacity-75"></i>Calories</a></li>
                <li class="nav-item d-none d-lg-block"><span class="text-muted px-1">|</span></li>
                <li class="nav-item">
                    <span class="nav-link mb-0"><i class="fas fa-circle-user text-success me-1"></i><?php echo htmlspecialchars($nav_user_name); ?></span>
                </li>
                <li class="nav-item ms-lg-1">
                    <a href="logout.php" class="btn btn-outline-danger btn-sm rounded-pill px-3"><i class="fas fa-sign-out-alt me-1"></i>Log out</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
