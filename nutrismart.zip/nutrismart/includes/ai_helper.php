<?php
/**
 * Server-side OpenAI Chat Completions (non-streaming). Tuned for XAMPP on Windows.
 */
require_once __DIR__ . '/../ai_config.php';

function nutrismart_ai_configured(): bool
{
    $k = trim((string) OPENAI_API_KEY);

    return $k !== '' && strlen($k) > 15;
}

/**
 * @param array<int, array{role: string, content: string}> $messages
 * @return array{ok: bool, text?: string, error?: string}
 */
function nutrismart_openai_chat(array $messages, float $temperature = 0.65, int $maxTokens = 1800): array
{
    if (!nutrismart_ai_configured()) {
        return ['ok' => false, 'error' => 'AI not configured (missing or invalid API key in ai_config.local.php)'];
    }

    $key = trim((string) OPENAI_API_KEY);
    $url = OPENAI_API_BASE . '/chat/completions';

    $headers = [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $key,
    ];
    if (defined('OPENAI_ORGANIZATION') && OPENAI_ORGANIZATION !== '') {
        $headers[] = 'OpenAI-Organization: ' . OPENAI_ORGANIZATION;
    }
    if (defined('OPENAI_PROJECT') && OPENAI_PROJECT !== '') {
        $headers[] = 'OpenAI-Project: ' . OPENAI_PROJECT;
    }

    // Try max_tokens first (standard Chat Completions); retry with max_completion_tokens if API rejects it
    $attempts = [
        ['max_tokens' => $maxTokens],
        ['max_completion_tokens' => $maxTokens],
    ];

    $lastErr = 'Unknown error';
    foreach ($attempts as $tokenParam) {
        $payload = array_merge([
            'model' => OPENAI_MODEL,
            'messages' => $messages,
            'temperature' => $temperature,
        ], $tokenParam);

        $body = json_encode($payload, JSON_UNESCAPED_UNICODE);
        if ($body === false) {
            return ['ok' => false, 'error' => 'JSON encode failed'];
        }

        $ch = curl_init($url);
        $opts = [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 120,
            CURLOPT_CONNECTTIMEOUT => 20,
        ];
        // Windows: some setups hang on IPv6 — prefer IPv4 when available
        if (defined('CURL_IPRESOLVE_V4')) {
            $opts[CURLOPT_IPRESOLVE] = CURL_IPRESOLVE_V4;
        }
        if (defined('OPENAI_SSL_VERIFY')) {
            $opts[CURLOPT_SSL_VERIFYPEER] = OPENAI_SSL_VERIFY;
            $opts[CURLOPT_SSL_VERIFYHOST] = OPENAI_SSL_VERIFY ? 2 : 0;
        }
        if (defined('OPENAI_CACERT') && OPENAI_CACERT !== '' && is_readable(OPENAI_CACERT)) {
            $opts[CURLOPT_CAINFO] = OPENAI_CACERT;
        }
        curl_setopt_array($ch, $opts);

        $raw = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $cerr = curl_error($ch);
        curl_close($ch);

        if ($raw === false) {
            return ['ok' => false, 'error' => $cerr ?: 'cURL network error — check internet, firewall, or set ssl_verify => false in ai_config.local.php only for local testing'];
        }

        $data = json_decode($raw, true);
        if ($code !== 200) {
            $msg = '';
            if (is_array($data) && isset($data['error'])) {
                if (is_string($data['error'])) {
                    $msg = $data['error'];
                } elseif (is_array($data['error']) && isset($data['error']['message'])) {
                    $msg = (string) $data['error']['message'];
                }
            }
            if ($msg === '') {
                $msg = 'HTTP ' . $code . ' — ' . substr(preg_replace('/\s+/', ' ', (string) $raw), 0, 280);
            }

            $retry = stripos($msg, 'max_tokens') !== false
                || stripos($msg, 'max_completion_tokens') !== false
                || stripos($msg, 'unsupported parameter') !== false;

            $lastErr = $msg;
            if ($retry && isset($tokenParam['max_tokens'])) {
                continue;
            }
            return ['ok' => false, 'error' => $msg];
        }

        if (!is_array($data)) {
            return ['ok' => false, 'error' => 'Invalid JSON from API'];
        }

        $choice = $data['choices'][0] ?? null;
        if (!is_array($choice)) {
            return ['ok' => false, 'error' => 'No choices in API response'];
        }

        $msgBlock = $choice['message'] ?? [];
        if (!is_array($msgBlock)) {
            return ['ok' => false, 'error' => 'Malformed message in API response'];
        }

        $content = $msgBlock['content'] ?? null;
        if ($content === null || $content === '') {
            if (!empty($msgBlock['refusal'])) {
                return ['ok' => false, 'error' => (string) $msgBlock['refusal']];
            }

            return ['ok' => false, 'error' => 'Empty model reply — check model name and billing on OpenAI.'];
        }

        return ['ok' => true, 'text' => trim(is_string($content) ? $content : '')];
    }

    return ['ok' => false, 'error' => $lastErr];
}
