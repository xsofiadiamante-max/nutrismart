<?php
/**
 * Offline nutrition & wellness knowledge for NutriSmart when live AI is unavailable.
 * Educational only—not medical advice. Sources: general WHO-style guidance, Dietary Guidelines patterns, and public health nutrition principles.
 */

function nutrismart_kb_disclaimer(): string
{
    return "\n\n— **Reminder:** This is general education for SEAIT students and staff. It does not replace a doctor, nurse, or registered dietitian—especially if you have allergies, diabetes, pregnancy, an eating disorder, or chronic illness.";
}

/**
 * Match user message to the best offline answer. Returns null if no strong match.
 */
function nutrismart_kb_match(string $msg): ?string
{
    $m = strtolower($msg);
    $m = preg_replace('/\s+/', ' ', $m);
    $bestText = null;
    $bestScore = 0;

    foreach (nutrismart_kb_entries() as $entry) {
        $score = 0;
        foreach ($entry['k'] as $kw) {
            if ($kw !== '' && strpos($m, strtolower($kw)) !== false) {
                $score += (int) ($entry['p'] ?? 1);
            }
        }
        $need = (int) ($entry['min'] ?? 1);
        if ($score >= $need && $score > $bestScore) {
            $bestScore = $score;
            $bestText = $entry['t'];
        }
    }

    return $bestText;
}

/**
 * @return array<int, array{k: string[], t: string, min?: int, p?: int}>
 */
function nutrismart_kb_entries(): array
{
    return [
        [
            'k' => ['bmi'],
            'min' => 1,
            'p' => 1,
            't' => "**BMI (quick offline answer)**\n\n"
                . "BMI is weight (kg) divided by height (m) squared. It is a **screening** tool for weight relative to height—not a direct measure of body fat. In NutriSmart, use the calculator, save your result, and read your **category** as a starting point for learning.\n\n"
                . "If you also type **underweight**, **normal**, **overweight**, or **obese** with your question, this guide can give a longer, category-specific explanation.",
        ],
        [
            'k' => ['bmi', 'underweight', 'category'],
            'min' => 2,
            'p' => 2,
            't' => "**BMI and the “underweight” category (education only)**\n\n"
                . "Body Mass Index (BMI) compares weight to height. A BMI below 18.5 is often classified as underweight in adults. That number alone does not tell the whole story—muscle, bone structure, genetics, and health conditions matter—but it can be a starting point for conversations with a clinician.\n\n"
                . "**Nutrition ideas people sometimes discuss** (not prescriptions): eating regular meals and snacks so energy intake matches needs; including protein (eggs, fish, chicken, tofu, beans, milk) with meals; adding healthy fats (nuts, avocado, olive oil) in modest amounts; choosing nutrient-dense foods rather than only low-volume items. Traditional Filipino options can include lugaw with egg, tinola with malunggay, ginisang monggo with rice, or fish with vegetables.\n\n"
                . "If unintentional weight loss, fatigue, or appetite changes are present, **see a health professional**—do not rely on apps alone.",
        ],
        [
            'k' => ['bmi', 'overweight', 'obese'],
            'min' => 2,
            'p' => 2,
            't' => "**BMI, “overweight,” and “obese” labels (screening, not judgment)**\n\n"
                . "For adults, BMI 25–29.9 is often grouped as overweight and 30+ as obese in broad screening. These categories help public health and research; they do **not** define your worth and may not fit athletes or very muscular people.\n\n"
                . "**Patterns often recommended in public health** (general, not for everyone): emphasize vegetables, fruits, and high-fiber foods; choose lean proteins; be mindful of portions of rice, bread, and sugary drinks; spread meals through the day to avoid extreme hunger; add enjoyable movement (walking, dancing, sports).\n\n"
                . "Filipino meals can stay culturally familiar: sinigang loaded with vegetables, grilled fish, more gulay, smaller rice portions, and water instead of repeated sugary beverages. For personalized targets, a **doctor or dietitian** can help.",
        ],
        [
            'k' => ['bmi', 'normal'],
            'min' => 2,
            'p' => 2,
            't' => "**BMI in the “normal” range**\n\n"
                . "A BMI roughly between 18.5 and 24.9 is often used as a broad “normal” band for adults. Staying there is not the only measure of health—fitness, diet quality, sleep, and mental health matter too.\n\n"
                . "**Maintenance ideas**: keep a varied plate (vegetables, protein, whole grains or root crops), stay hydrated, limit ultra-processed snacks as everyday staples, and keep moving in ways you enjoy. NutriSmart’s tools can help you **track patterns** over time rather than chasing a single number each day.",
        ],
        [
            'k' => ['bmi', 'what is', 'explain'],
            'min' => 2,
            'p' => 2,
            't' => "**What is BMI?**\n\n"
                . "BMI is weight in kilograms divided by height in meters squared (kg/m²). It is a **quick, inexpensive screening tool** used in many clinics and research studies. It does **not** measure body fat directly and can misclassify some people (for example, very muscular athletes).\n\n"
                . "Common adult cutoffs (may differ for teens and older adults): underweight below 18.5; “normal” about 18.5–24.9; overweight about 25–29.9; obesity 30 and above. Always interpret results with a professional if you have health concerns.",
        ],
        [
            'k' => ['filipino', 'meal', 'rice'],
            'min' => 2,
            'p' => 2,
            't' => "**Filipino meals and balanced eating**\n\n"
                . "Many Filipino dishes already combine starch (rice, noodles, corn), protein (fish, chicken, pork, tofu), and vegetables (pinakbet, laing, monggo). **Reliable patterns** include: fill half the plate with vegetables when you can; keep ulam portions moderate; if rice is large, consider **one less scoop** or mixing in corn or brown rice gradually; choose cooking methods like grill, boil, or stew with less repeated deep-frying.\n\n"
                . "Examples: tinola or sinigang with extra vegetables; grilled bangus with ensalada; adobo with plenty of sauce on vegetables and controlled rice; arroz caldo or lugaw with egg for a warm breakfast. **Sugar in drinks** (sago’t gulaman, sweetened coffee, soda) adds energy quickly—water, buko juice in moderation, or unsweetened tea are common swaps people discuss.",
        ],
        [
            'k' => ['pinoy', 'ulam', 'healthy'],
            'min' => 2,
            'p' => 2,
            't' => "**Healthier Pinoy-style choices (ideas, not rules)**\n\n"
                . "**Ulam** often brings flavor and protein—pair it with **gulay** so meals feel full with fiber and vitamins. Try: ginisang sitaw at kalabasa, pinakbet, laing (mind coconut frequency if portions are large), tortang talong with less oil absorption tricks, or inihaw na isda.\n\n"
                . "For **merienda**, combine carbs with protein when possible: banana + peanuts, puto + egg, or fruit instead of only fried snacks every day. **Rice** is cultural fuel—adjusting portion or eating slowly can help awareness without banning a staple.",
        ],
        [
            'k' => ['student', 'study', 'exam'],
            'min' => 2,
            'p' => 2,
            't' => "**Eating during busy school terms (SEAIT-style campus life)**\n\n"
                . "Long classes and deadlines can push people toward skipped meals or late-night fast food. **Reliable habits** that many students find helpful: keep affordable snacks in your bag (fruit, nuts, crackers with peanut butter); eat breakfast or a morning meal when possible so focus lasts through morning lectures; hydrate—mild dehydration can feel like tiredness or hunger.\n\n"
                . "Before exams, **avoid huge unfamiliar meals** that upset your stomach; choose familiar, balanced plates and steady caffeine instead of excess energy drinks. Sleep still beats all-nighters for memory—nutrition supports, but rest is king.",
        ],
        [
            'k' => ['hydrat', 'water', 'drink'],
            'min' => 1,
            'p' => 2,
            't' => "**Hydration: practical guidance**\n\n"
                . "Water carries nutrients, supports temperature regulation, and helps digestion. **General ideas** (needs vary by sweat, climate, and health): sip through the day; pale yellow urine often suggests adequate intake for many people; during long walks between classes or PE, drink before you feel very thirsty.\n\n"
                . "Sweetened juices, soda, and specialty coffee drinks can add **many calories** without fullness—enjoy them sometimes, not as your only fluids. If you have **heart or kidney conditions**, fluid targets may differ—follow your clinician’s advice.",
        ],
        [
            'k' => ['protein', 'muscle'],
            'min' => 1,
            'p' => 2,
            't' => "**Protein basics**\n\n"
                . "Protein helps build and repair tissues and can help you feel full. Sources include fish, chicken, lean meat, eggs, milk, yogurt, tofu, tempeh, beans, lentils, and peanuts. **Spreading protein** across meals is a pattern many nutrition guides mention rather than one huge serving at dinner only.\n\n"
                . "Very high-protein diets are **not** automatically safe for everyone—people with kidney disease need medical guidance. For general campus life, balanced meals with a palm-sized protein portion (as a rough visual) are a common starting point in many handouts.",
        ],
        [
            'k' => ['carb', 'rice', 'bread'],
            'min' => 1,
            'p' => 2,
            't' => "**Carbohydrates (carbs)**\n\n"
                . "Carbs are the body’s main energy source. They include rice, bread, pasta, corn, potatoes, fruits, milk, and sweets. **Fiber-rich carbs**—brown rice, oats, whole wheat, beans, fruits with skin—often support steadier energy than refined carbs alone.\n\n"
                . "You do **not** need to fear rice culturally; many dietitians focus on **portion**, frequency of sweets, and what else is on the plate (vegetables, protein). Athletes and active people often need **more** carbs, not fewer—context matters.",
        ],
        [
            'k' => ['fat', 'oil', 'cholesterol'],
            'min' => 1,
            'p' => 2,
            't' => "**Fats and oils (overview)**\n\n"
                . "Fats help absorb some vitamins and support hormones. **Unsaturated fats** (fish, nuts, olive oil, canola, avocado) are often emphasized in heart-health messaging. **Saturated fats** (fatty cuts, coconut cream in large amounts, palm oil in some snacks) are often limited in general guidelines—not eliminated overnight, but not the only fat source every meal.\n\n"
                . "**Trans fats** (some old fried/processed products) are widely discouraged. Cooking: steaming, boiling, grilling, and using measured oil can reduce excess. Blood cholesterol is influenced by many factors—**only your clinician** should interpret labs.",
        ],
        [
            'k' => ['fiber', 'constipation', 'digest'],
            'min' => 1,
            'p' => 2,
            't' => "**Fiber and digestion**\n\n"
                . "Fiber supports bowel regularity and can help with fullness. It is found in vegetables, fruits, beans, lentils, oats, and whole grains. **Increase fiber gradually** and drink enough water—going too fast can cause bloating for some people.\n\n"
                . "If constipation is ongoing or painful, or you see blood in stool, **see a doctor**—do not self-diagnose with internet tips alone.",
        ],
        [
            'k' => ['vitamin', 'mineral', 'iron'],
            'min' => 1,
            'p' => 2,
            't' => "**Vitamins and minerals (big picture)**\n\n"
                . "Micronutrients (iron, calcium, vitamin D, B vitamins, iodine, etc.) support energy, bones, blood, and immunity. **Food-first** approaches are common: leafy greens and lean meat for iron (absorption improves with vitamin C foods); dairy or fortified soy for calcium; sunlight and fortified foods often come up for vitamin D in discussions.\n\n"
                . "**Supplements** are not automatically necessary for everyone—high doses can be harmful. Ask a **pharmacist or doctor** before starting supplements, especially if you take medicines.",
        ],
        [
            'k' => ['calorie', 'energy', 'kcal'],
            'min' => 1,
            'p' => 2,
            't' => "**Calories (energy) awareness**\n\n"
                . "A calorie (kilocalorie) is a unit of energy from food. **Needs differ** by age, sex, height, weight, muscle mass, and activity—there is no single “2000 for everyone” truth. Apps and calculators give **estimates**.\n\n"
                . "NutriSmart’s **manual calorie log** helps you notice patterns (heavy snacking days, skipped meals). Use numbers as **feedback**, not punishment. If you are told to gain or lose weight for medical reasons, a **dietitian** can set safer targets than social media trends.",
        ],
        [
            'k' => ['sleep', 'rest', 'insomnia'],
            'min' => 1,
            'p' => 2,
            't' => "**Sleep and eating behavior**\n\n"
                . "Short sleep is linked in research to stronger appetite signals and more cravings for energy-dense foods—partly through hormones like ghrelin and leptin (simplified). **Aim for regular sleep** when schedules allow; 7–9 hours is a common adult range in many guidelines, with individual variation.\n\n"
                . "Late-night studying often pairs with **extra snacks and caffeine**—small planned snacks (fruit, milk, sandwich) beat endless chips on an empty stomach. Chronic insomnia deserves **clinical attention**, not only diet tips.",
        ],
        [
            'k' => ['stress', 'anxiety', 'mental'],
            'min' => 1,
            'p' => 2,
            't' => "**Stress, mood, and food**\n\n"
                . "Some people eat less when stressed; others eat more or crave sweets. **Neither pattern** defines your character—it is human. Helpful ideas: keep regular meal times when possible; notice **emotional eating** without harsh self-judgment; try short walks, breathing, or campus counseling services.\n\n"
                . "If food and body image feel overwhelming, **eating-disorder specialists** save lives—reach out early.",
        ],
        [
            'k' => ['diabetes', 'blood sugar'],
            'min' => 1,
            'p' => 2,
            't' => "**Blood sugar and diabetes (general education)**\n\n"
                . "Diabetes care is **individual**—carb amounts, meal timing, and medicines depend on your doctor’s plan. Public messages often emphasize: consistent meals; **limiting sugary drinks**; pairing carbs with protein/fiber; monitoring as your team prescribes.\n\n"
                . "NutriSmart is **not** a medical device. If you have diabetes or symptoms (thirst, frequent urination, blurry vision), **seek professional care**—do not tune insulin or medicines from chat advice.",
        ],
        [
            'k' => ['allergy', 'allergic'],
            'min' => 1,
            'p' => 2,
            't' => "**Food allergies**\n\n"
                . "Allergies can be life-threatening (for example, some peanut or shellfish reactions). **Strict avoidance** of the allergen, reading labels, and carrying prescribed emergency medicine are standard medical topics—not something to guess from a wellness chat.\n\n"
                . "If you suspect an allergy, see an **allergist**. NutriSmart does not diagnose allergies.",
        ],
        [
            'k' => ['vegetarian', 'vegan', 'plant'],
            'min' => 1,
            'p' => 2,
            't' => "**Plant-based eating**\n\n"
                . "Vegetarian and vegan patterns can be healthy with planning. **Pay attention to**: protein (tofu, tempeh, beans, lentils, nuts), iron (leafy greens + vitamin C foods), vitamin B12 (fortified foods or supplements as advised), calcium (fortified soy milk, greens), and omega-3s (algae supplements sometimes used).\n\n"
                . "Filipino plant plates: ginisang monggo, tofu sisig-style dishes, laing, pinakbet without meat if that fits your tradition. A **dietitian** can help avoid gaps.",
        ],
        [
            'k' => ['breakfast', 'almusal'],
            'min' => 1,
            'p' => 2,
            't' => "**Breakfast and morning energy**\n\n"
                . "Eating something in the morning can support focus for early classes—whether that is pandesal with peanut butter, oats, egg and rice, or fruit plus milk depends on culture, budget, and time.\n\n"
                . "If you skip breakfast, **plan a mid-morning snack** so you do not arrive at lunch overly hungry. Sugary drinks alone often crash energy later—pair carbs with a little protein when possible.",
        ],
        [
            'k' => ['snack', 'merienda', 'junk food'],
            'min' => 1,
            'p' => 2,
            't' => "**Snacks and merienda**\n\n"
                . "Snacks are not “bad”—they bridge long gaps between meals. **Ideas**: fruit, boiled egg, nuts (small handful), yogurt, cheese, whole-grain crackers, or homemade sandwiches. **Ultra-processed** bags of chips or sweets can be occasional treats, not the only option daily if your goal is steadier energy.\n\n"
                . "Share snacks with friends to reduce cost and portion size—common campus strategy.",
        ],
        [
            'k' => ['exercise', 'workout', 'gym', 'sport'],
            'min' => 1,
            'p' => 2,
            't' => "**Food and movement**\n\n"
                . "Activity supports heart health, mood, and weight management alongside nutrition. **WHO-style messaging** often mentions ~150 minutes of moderate activity per week plus strength work—walking between buildings counts as a start.\n\n"
                . "Around workouts: a small carb+protein snack may help if sessions are long; **rehydrate** with water; extreme diets plus heavy training can risk injury—student athletes should follow **coach and sports medicine** guidance.",
        ],
        [
            'k' => ['lose weight', 'weight loss', 'slim'],
            'min' => 2,
            'p' => 2,
            't' => "**Weight loss: cautious, general framing**\n\n"
                . "Sustainable change usually combines **eating patterns you can keep**, movement you tolerate, sleep, and stress care. Very low calories or “detox” products often backfire. **Slow, steady** progress is often safer than crash diets.\n\n"
                . "NutriSmart can show **BMI categories** and meal ideas for awareness—**not** a guarantee of results. If weight affects health (blood pressure, sleep apnea, etc.), involve **clinicians**.",
        ],
        [
            'k' => ['gain weight', 'gain', 'thin'],
            'min' => 2,
            'p' => 2,
            't' => "**Healthy weight gain (when appropriate)**\n\n"
                . "If a clinician says you need to gain weight, they may suggest **nutrient-dense** foods: nuts, avocados, full-fat milk (if tolerated), extra servings of rice or potatoes, and protein at each meal. **Frequent small meals** help when appetite is low.\n\n"
                . "Unintentional weight loss should be **evaluated medically**—do not only “eat more” without knowing the cause.",
        ],
        [
            'k' => ['meal prep', 'budget', 'cheap'],
            'min' => 2,
            'p' => 2,
            't' => "**Budget-friendly healthy eating**\n\n"
                . "Eggs, canned fish, tofu, monggo, seasonal vegetables, and bulk rice are staples in many Filipino households. **Cooking at home** with housemates can split costs. **Frozen vegetables** and **canned beans** (rinsed) can be affordable and quick.\n\n"
                . "Plan a loose weekly menu so you buy only what you need—reduces waste and impulse junk food.",
        ],
        [
            'k' => ['nutrismart', 'dashboard', 'app'],
            'min' => 1,
            'p' => 2,
            't' => "**Using NutriSmart (this system)**\n\n"
                . "**BMI calculator**: enter height, weight, and optional age/activity—save readings to history. **Meal planner**: can show template meals by category or AI text when the API works. **Calorie log**: pick multiple foods and servings to log your day. **Chat**: this offline guide answers many topics when live AI is off.\n\n"
                . "Nothing here replaces **professional care** for medical nutrition therapy.",
        ],
        [
            'k' => ['salt', 'sodium', 'bp', 'blood pressure'],
            'min' => 1,
            'p' => 2,
            't' => "**Salt and sodium**\n\n"
                . "High sodium intake is linked to higher blood pressure in many people. **Common sources**: instant noodles, canned goods, fast food, salty snacks, and heavy patis/bagoong use. **Ideas**: cook more at home; taste before adding salt; use calamansi, vinegar, garlic, and herbs for flavor.\n\n"
                . "If you have hypertension, follow your **doctor’s sodium target**—generic chat cannot set it.",
        ],
        [
            'k' => ['coffee', 'caffeine', 'energy drink'],
            'min' => 1,
            'p' => 2,
            't' => "**Caffeine and energy drinks**\n\n"
                . "Moderate coffee or tea is fine for many adults; **sensitivity varies** (sleep, anxiety, palpitations). Energy drinks combine caffeine with sugar and other stimulants—**large amounts** can be risky, especially mixed with alcohol or little food.\n\n"
                . "If your heart races or you feel unwell, **cut back** and talk to a clinician.",
        ],
        [
            'k' => ['pregnant', 'pregnancy', 'breastfeed'],
            'min' => 1,
            'p' => 2,
            't' => "**Pregnancy and breastfeeding**\n\n"
                . "Nutrient needs change in pregnancy and lactation—**folic acid, iron, calcium, iodine**, and overall energy often increase. **Do not** take high-dose supplements or restrictive diets without **obstetric and nutrition guidance**.\n\n"
                . "This chat cannot provide prenatal meal plans.",
        ],
        [
            'k' => ['eating disorder', 'anorexia', 'bulimia', 'binge'],
            'min' => 1,
            'p' => 2,
            't' => "**If food feels out of control or frightening**\n\n"
                . "Eating disorders are serious mental health conditions. **You deserve professional support**—counseling, medical monitoring, and sometimes family-based therapy. If you or a friend restricts, binges, purges, or exercises compulsively, **reach out to campus health services or a crisis line** in your area.\n\n"
                . "NutriSmart is **not** a treatment program.",
        ],
    ];
}

/**
 * Long default answer when no keyword cluster matches—still educational and on-topic.
 */
function nutrismart_kb_default_guide(): string
{
    return "**Nutrition & wellness topics you can ask about (offline guide)**\n\n"
        . "**Body metrics:** What BMI means, how categories work, why height and weight together matter, and limits of BMI (athletes, older adults). Ask about “underweight,” “normal,” “overweight,” or “obese” in a learning sense—not as labels about you as a person.\n\n"
        . "**Filipino food culture:** Balancing rice and ulam, vegetable-forward dishes (pinakbet, laing, monggo), soups with malunggay, grilled fish, and how to enjoy lechon or fried food on occasions without making them the only pattern.\n\n"
        . "**Macronutrients:** Protein sources and spacing; carbs as energy and fiber; fats—cooking oils, coconut, nuts—and heart-health messaging in general guidelines.\n\n"
        . "**Micronutrients:** Iron and vitamin C pairs; calcium and bone health; why variety beats single “superfoods.”\n\n"
        . "**Campus life:** Breakfast before class, merienda that isn’t only chips, hydration in heat, caffeine without wrecking sleep, and budget meals with roommates.\n\n"
        . "**Movement:** Walking between buildings, PE, gym basics, and why nutrition supports but doesn’t replace training plans from coaches.\n\n"
        . "**Mind and body:** Sleep and appetite; stress eating; when to see counselors for food anxiety.\n\n"
        . "**Conditions (general only):** Diabetes, allergies, pregnancy—why individualized medical care matters and why this chat stays educational.\n\n"
        . "**How to use NutriSmart:** BMI history, meal planner templates, multi-item calorie log, and (when billing allows) live AI for tailored wording.\n\n"
        . "Try rephrasing with a word from the list above—e.g. “hydration,” “Pinoy ulam,” “protein,” “exam food,” “sleep”—for a longer focused answer.";
}
