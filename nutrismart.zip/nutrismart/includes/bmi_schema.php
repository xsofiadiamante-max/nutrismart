<?php
/**
 * Ensure optional BMI columns exist (age, sex, activity_level).
 */
function nutrismart_ensure_bmi_columns(mysqli $conn): void
{
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    $r = $conn->query("SHOW COLUMNS FROM bmi_records LIKE 'age'");
    if ($r && $r->num_rows === 0) {
        @$conn->query("ALTER TABLE bmi_records ADD COLUMN age SMALLINT UNSIGNED NULL DEFAULT NULL");
        @$conn->query("ALTER TABLE bmi_records ADD COLUMN sex VARCHAR(16) NULL DEFAULT NULL");
        @$conn->query("ALTER TABLE bmi_records ADD COLUMN activity_level VARCHAR(32) NULL DEFAULT NULL");
    }
}
