<?php
session_start();
include __DIR__ . '/db.php';
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
$email_esc = $conn->real_escape_string($_SESSION['user']);
$user_res = $conn->query("SELECT name FROM users WHERE email='$email_esc' LIMIT 1");
$user = $user_res ? $user_res->fetch_assoc() : null;
if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}
require_once __DIR__ . '/includes/ai_helper.php';
$aiLive = nutrismart_ai_configured();
$today = date('Y-m-d');
$calRes = $conn->query("SELECT SUM(calories) AS total FROM calorie_log WHERE user_email='$email_esc' AND DATE(logged_at)='$today'");
$calRow = $calRes ? $calRes->fetch_assoc() : null;
$calToday = $calRow && $calRow['total'] !== null ? (int) $calRow['total'] : 0;
$goalCol = $conn->query("SHOW COLUMNS FROM users LIKE 'daily_calorie_goal'");
if ($goalCol && $goalCol->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN daily_calorie_goal INT NULL DEFAULT 2000");
}
$goalRes = $conn->query("SELECT daily_calorie_goal FROM users WHERE email='$email_esc' LIMIT 1");
$goalRow = $goalRes ? $goalRes->fetch_assoc() : null;
$calGoal = $goalRow && (int)$goalRow['daily_calorie_goal'] > 0 ? (int)$goalRow['daily_calorie_goal'] : 2000;
$bmiRes = $conn->query("SELECT category FROM bmi_records WHERE user_email='$email_esc' ORDER BY id DESC LIMIT 1");
$bmiRow = $bmiRes ? $bmiRes->fetch_assoc() : null;
$bmiCategory = $bmiRow ? (string) $bmiRow['category'] : 'Not set';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <title>AI Nutrition Chat — NutriSmart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
    <style>
        .chat-card {
            background: rgba(255, 255, 255, 0.97);
            backdrop-filter: blur(16px);
            border-radius: 28px;
            overflow: hidden;
            box-shadow: 0 24px 64px rgba(15, 23, 42, 0.18);
            margin: 0 0 2rem;
            height: 80vh;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(255,255,255,0.5);
        }
        .chat-header {
            background: var(--ns-gradient);
            color: white;
            padding: 20px 30px;
            display: flex;
            align-items: center;
        }
        .chat-header h3 { margin: 0; font-weight: 600; }
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 30px;
            background: #f8f9fa;
        }
        .message {
            display: flex;
            flex-direction: row;
            align-items: flex-end;
            margin-bottom: 20px;
            animation: fadeIn 0.3s ease;
        }
        .message.user { flex-direction: row-reverse; }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .message-content {
            max-width: 75%;
            padding: 12px 20px;
            border-radius: 20px;
            font-size: 0.95rem;
            line-height: 1.55;
        }
        .message.user .message-content {
            background: var(--ns-gradient);
            color: white;
            border-bottom-right-radius: 6px;
            box-shadow: 0 6px 20px rgba(13, 148, 136, 0.28);
        }
        .message.bot .message-content {
            background: white;
            color: #333;
            border-bottom-left-radius: 6px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .message-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 10px;
            flex-shrink: 0;
        }
        .message.bot .message-avatar {
            background: var(--ns-gradient);
            color: white;
        }
        .message.user .message-avatar {
            background: #6c757d;
            color: white;
        }
        .chat-footer {
            padding: 20px 30px;
            background: white;
            border-top: 1px solid #dee2e6;
        }
        .input-group {
            border-radius: 50px;
            overflow: hidden;
            border: 2px solid #e0e0e0;
            transition: all 0.3s;
        }
        .input-group:focus-within {
            border-color: var(--ns-teal);
            box-shadow: 0 0 0 4px rgba(13, 148, 136, 0.12);
        }
        .input-group input {
            border: none;
            padding: 15px 20px;
            font-size: 1rem;
        }
        .input-group input:focus { box-shadow: none; }
        .input-group button {
            background: var(--ns-gradient);
            color: white;
            border: none;
            padding: 0 25px;
            font-size: 1.2rem;
        }
        .typing-indicator {
            display: flex;
            padding: 12px 20px;
            background: white;
            border-radius: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: fit-content;
        }
        .typing-indicator span {
            width: 8px;
            height: 8px;
            background: var(--ns-teal);
            border-radius: 50%;
            margin: 0 2px;
            animation: typing 1.4s infinite;
        }
        .typing-indicator span:nth-child(2) { animation-delay: 0.2s; }
        .typing-indicator span:nth-child(3) { animation-delay: 0.4s; }
        @keyframes typing {
            0%, 60%, 100% { transform: translateY(0); }
            30% { transform: translateY(-10px); }
        }
        .suggestions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }
        .suggestion-chip {
            background: #f0f0f0;
            padding: 8px 15px;
            border-radius: 50px;
            font-size: 0.9rem;
            cursor: pointer;
            border: none;
        }
        .suggestion-chip:hover { background: #e0e0e0; }
        .chat-context {
            background: rgba(255,255,255,.92);
            border: 1px solid rgba(15,23,42,.08);
            border-radius: 14px;
            padding: .6rem .8rem;
            margin-bottom: .75rem;
        }
    </style>
</head>
<body class="ns-body ns-page-app ns-overlay-dark">
    <?php $ns_nav_active = 'chat'; include __DIR__ . '/includes/app_nav.php'; ?>
    <div class="container position-relative ns-z-main pb-4">
        <div class="chat-context">
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
                <div class="small text-secondary">
                    <strong><?php echo htmlspecialchars((string) $user['name'], ENT_QUOTES, 'UTF-8'); ?></strong> ·
                    Today: <strong><?php echo (int) $calToday; ?>/<?php echo (int) $calGoal; ?> kcal</strong> ·
                    BMI: <strong><?php echo htmlspecialchars($bmiCategory, ENT_QUOTES, 'UTF-8'); ?></strong>
                </div>
                <div class="d-flex gap-2">
                    <a href="meal_planner.php" class="btn btn-sm btn-outline-success rounded-pill"><i class="fas fa-utensils me-1"></i>Meals</a>
                    <a href="calorie_tracker.php" class="btn btn-sm btn-outline-primary rounded-pill"><i class="fas fa-fire me-1"></i>Log</a>
                </div>
            </div>
        </div>
        <div class="chat-card ns-chat-shell">
            <div class="chat-header">
                <div class="d-flex align-items-center">
                    <div class="bg-white rounded-circle p-2 me-3" style="color:var(--ns-teal-dark);">
                        <i class="fas fa-robot fa-2x"></i>
                    </div>
                    <div>
                        <h3 class="mb-0">Live AI nutrition chat</h3>
                        <small class="opacity-90">
                            <?php echo $aiLive
                                ? '<i class="fas fa-circle text-success me-1"></i> Live AI on · detailed offline guide still available'
                                : '<i class="fas fa-circle text-info me-1"></i> Offline knowledge base · type <strong>help</strong> for topics (fix API billing for live AI)'; ?>
                        </small>
                    </div>
                </div>
            </div>
            
            <div class="chat-messages" id="chatMessages">
                <div class="message bot">
                    <div class="message-avatar"><i class="fas fa-robot"></i></div>
                    <div class="message-content">
                        Hi! Ask about <strong>BMI</strong>, <strong>Filipino meals</strong>, <strong>hydration</strong>, <strong>sleep</strong>, <strong>stress eating</strong>, or type <strong>help</strong> for topics. Offline answers are detailed when live AI is off.<br>
                        <small class="text-muted">Not a substitute for a doctor or dietitian. <?php echo $aiLive ? '' : 'With no API quota, this guide still answers from a built-in knowledge base.'; ?></small>
                    </div>
                </div>
            </div>
            
            <div class="chat-footer">
                <div class="suggestions" id="suggestions">
                    <button type="button" class="suggestion-chip" onclick="sendSuggestion('Based on my data today (' + <?php echo json_encode((string) $calToday); ?> + ' kcal and BMI ' + <?php echo json_encode($bmiCategory); ?> + '), what should I eat next?')">
                        <i class="fas fa-sparkles me-1"></i>Use my current data
                    </button>
                    <button type="button" class="suggestion-chip" onclick="sendSuggestion('Give me 5 practical habits to stay healthy during busy school weeks at SEAIT')">
                        <i class="fas fa-school me-1"></i> Healthy campus habits
                    </button>
                    <button type="button" class="suggestion-chip" onclick="sendSuggestion('How should I eat if my BMI category is overweight? General ideas only.')">
                        <i class="fas fa-scale-balanced me-1"></i> BMI-aware eating
                    </button>
                    <button type="button" class="suggestion-chip" onclick="sendSuggestion('Simple Filipino meals that are filling but lighter')">
                        <i class="fas fa-bowl-rice me-1"></i> Filipino meals
                    </button>
                    <button type="button" class="suggestion-chip" onclick="sendSuggestion('How much water should I aim for in a hot day?')">
                        <i class="fas fa-droplet me-1"></i> Hydration
                    </button>
                    <button type="button" class="suggestion-chip" onclick="sendSuggestion('help')">
                        <i class="fas fa-book me-1"></i> Topic list (offline)
                    </button>
                    <button type="button" class="suggestion-chip" onclick="clearChat()">
                        <i class="fas fa-trash me-1"></i> Clear chat
                    </button>
                </div>
                
                <div class="input-group mt-2">
                    <input type="text" id="userInput" class="form-control" placeholder="Ask about healthy living…" autocomplete="off"
                           onkeydown="if(event.key==='Enter'){event.preventDefault();sendMessage();}">
                    <button type="button" onclick="sendMessage()" aria-label="Send"><i class="fas fa-paper-plane"></i></button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const chatMessages = document.getElementById('chatMessages');
        const userInput = document.getElementById('userInput');
        let conversation = [];

        function escapeHtml(s) {
            const d = document.createElement('div');
            d.textContent = s;
            return d.innerHTML;
        }
        function formatBotText(t) {
            const chunks = String(t).split(/\*\*/);
            let out = '';
            for (let i = 0; i < chunks.length; i++) {
                const part = chunks[i];
                if (i % 2 === 1) {
                    out += '<strong>' + escapeHtml(part) + '</strong>';
                } else {
                    out += escapeHtml(part).replace(/\n/g, '<br>');
                }
            }
            return out;
        }

        function addMessage(text, isUser) {
            const messageDiv = document.createElement('div');
            messageDiv.className = 'message ' + (isUser ? 'user' : 'bot');

            const avatar = document.createElement('div');
            avatar.className = 'message-avatar';
            avatar.innerHTML = isUser ? '<i class="fas fa-user"></i>' : '<i class="fas fa-robot"></i>';

            const content = document.createElement('div');
            content.className = 'message-content';
            if (isUser) {
                content.textContent = text;
            } else {
                content.innerHTML = formatBotText(text);
            }

            if (isUser) {
                messageDiv.appendChild(content);
                messageDiv.appendChild(avatar);
            } else {
                messageDiv.appendChild(avatar);
                messageDiv.appendChild(content);
            }

            chatMessages.appendChild(messageDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function showTyping() {
            const typingDiv = document.createElement('div');
            typingDiv.className = 'message bot';
            typingDiv.id = 'typingIndicator';
            typingDiv.innerHTML = '<div class="message-avatar"><i class="fas fa-robot"></i></div>' +
                '<div class="typing-indicator"><span></span><span></span><span></span></div>';
            chatMessages.appendChild(typingDiv);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function removeTyping() {
            const typing = document.getElementById('typingIndicator');
            if (typing) typing.remove();
        }

        function sendMessage() {
            const message = userInput.value.trim();
            if (message === '') return;

            addMessage(message, true);
            userInput.value = '';
            conversation.push({ role: 'user', content: message });
            if (conversation.length > 24) {
                conversation = conversation.slice(-24);
            }

            showTyping();

            fetch('chatbot_api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ messages: conversation }),
                credentials: 'same-origin'
            })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    removeTyping();
                    if (!data.ok) {
                        addMessage(data.error || 'Error', false);
                        return;
                    }
                    if (data.source === 'fallback' && data.ai_error && data.ai_error !== 'not_configured') {
                        console.warn('[NutriSmart AI]', data.ai_error);
                    }
                    conversation.push({ role: 'assistant', content: data.text });
                    if (conversation.length > 24) {
                        conversation = conversation.slice(-24);
                    }
                    addMessage(data.text, false);
                })
                .catch(function () {
                    removeTyping();
                    addMessage('Network error. Check your connection and try again.', false);
                });
        }

        function sendSuggestion(text) {
            userInput.value = text;
            sendMessage();
        }
        function clearChat() {
            conversation = [];
            const blocks = chatMessages.querySelectorAll('.message');
            blocks.forEach((b, idx) => { if (idx > 0) b.remove(); });
        }
    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
