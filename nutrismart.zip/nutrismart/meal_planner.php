<?php
session_start();
include "db.php";
require_once __DIR__ . '/includes/bmi_schema.php';
require_once __DIR__ . '/includes/ai_helper.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

nutrismart_ensure_bmi_columns($conn);

$logCols = [];
$logColsRes = $conn->query("SHOW COLUMNS FROM calorie_log");
if ($logColsRes) {
    while ($c = $logColsRes->fetch_assoc()) {
        $logCols[$c['Field']] = true;
    }
}
if (!isset($logCols['meal_type'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN meal_type VARCHAR(20) NULL DEFAULT 'snack' AFTER food");
}
if (!isset($logCols['servings'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN servings DECIMAL(6,2) NULL DEFAULT 1 AFTER calories");
}
if (!isset($logCols['notes'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN notes VARCHAR(255) NULL AFTER servings");
}
if (!isset($logCols['protein_g'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN protein_g DECIMAL(8,2) NULL DEFAULT 0 AFTER notes");
}
if (!isset($logCols['carbs_g'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN carbs_g DECIMAL(8,2) NULL DEFAULT 0 AFTER protein_g");
}
if (!isset($logCols['fat_g'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN fat_g DECIMAL(8,2) NULL DEFAULT 0 AFTER carbs_g");
}

$email = $_SESSION['user'];
$email_esc = $conn->real_escape_string($email);
$user_res = $conn->query("SELECT name FROM users WHERE email='$email_esc' LIMIT 1");
$user = $user_res ? $user_res->fetch_assoc() : null;
if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}
$goalCol = $conn->query("SHOW COLUMNS FROM users LIKE 'daily_calorie_goal'");
if ($goalCol && $goalCol->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN daily_calorie_goal INT NULL DEFAULT 2000");
}
$goalRes = $conn->query("SELECT daily_calorie_goal FROM users WHERE email='$email_esc' LIMIT 1");
$goalRow = $goalRes ? $goalRes->fetch_assoc() : null;
$dailyGoal = $goalRow && (int)$goalRow['daily_calorie_goal'] > 0 ? (int)$goalRow['daily_calorie_goal'] : 2000;
$flash = '';
$flashType = 'success';

if (isset($_POST['save_template_to_log'])) {
    $foodName = trim((string) ($_POST['food_name'] ?? ''));
    $calories = max(0, (int) ($_POST['food_calories'] ?? 0));
    $mealType = strtolower(trim((string) ($_POST['meal_type'] ?? 'snack')));
    $allowedMeals = ['breakfast', 'lunch', 'dinner', 'snack'];
    if (!in_array($mealType, $allowedMeals, true)) {
        $mealType = 'snack';
    }
    if ($foodName !== '' && $calories > 0) {
        $foodEsc = $conn->real_escape_string($foodName);
        $mealEsc = $conn->real_escape_string($mealType);
        $noteEsc = $conn->real_escape_string('Added from meal planner template');
        $conn->query("INSERT INTO calorie_log (user_email, food, meal_type, calories, servings, notes) VALUES ('$email_esc', '$foodEsc', '$mealEsc', '$calories', 1, '$noteEsc')");
        $flash = 'Meal item added to your calorie log.';
    } else {
        $flash = 'Could not add this meal item.';
        $flashType = 'danger';
    }
}

$bmi_result = $conn->query("SELECT category, bmi, age, sex, activity_level FROM bmi_records WHERE user_email='$email_esc' ORDER BY id DESC LIMIT 1");
$bmi_row = $bmi_result ? $bmi_result->fetch_assoc() : null;
$category = $bmi_row ? $bmi_row['category'] : null;
$has_bmi = $bmi_row !== null;

$cat_esc = $category ? $conn->real_escape_string($category) : '';
$meals = ($category !== null) ? $conn->query("SELECT * FROM meal_plans WHERE category='$cat_esc'") : null;

$aiReady = nutrismart_ai_configured();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <title>Meal Planner — NutriSmart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
    <style>
        .category-badge {
            background: rgba(255,255,255,0.2);
            padding: 8px 25px;
            border-radius: 50px;
            display: inline-block;
            margin-top: 15px;
        }
        .ai-output {
            background: #f8fafc;
            border: 1px solid rgba(13, 148, 136, 0.25);
            border-radius: 16px;
            padding: 1.25rem;
            white-space: pre-wrap;
            word-break: break-word;
            font-size: 0.95rem;
            line-height: 1.55;
            max-height: 70vh;
            overflow-y: auto;
        }
        .meal-time {
            background: linear-gradient(135deg, #f6f9fc 0%, #e6f0f9 100%);
            border-radius: 15px;
            padding: 20px;
            margin-bottom: 20px;
            border-left: 5px solid var(--ns-teal);
        }
        .meal-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--ns-gradient);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        .food-item {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .calorie-badge {
            background: #28a745;
            color: white;
            padding: 5px 15px;
            border-radius: 50px;
            font-weight: bold;
        }
        .total-calories {
            background: var(--ns-gradient);
            color: white;
            padding: 20px;
            border-radius: 15px;
            text-align: center;
            margin-top: 30px;
        }
        .btn-ai {
            background: linear-gradient(135deg, #059669 0%, #0d9488 100%);
            color: #fff;
            border: none;
            border-radius: 999px;
            padding: 0.65rem 1.5rem;
            font-weight: 600;
        }
        .btn-ai:disabled { opacity: 0.65; }
        .insight-chip {
            background: rgba(255,255,255,0.18);
            border: 1px solid rgba(255,255,255,0.35);
            border-radius: 999px;
            padding: .35rem .8rem;
            font-size: .82rem;
            display: inline-flex;
            align-items: center;
            gap: .35rem;
            margin: .15rem;
        }
    </style>
</head>
<body class="ns-body ns-page-app ns-overlay-dark">
    <?php $ns_nav_active = 'meals'; include __DIR__ . '/includes/app_nav.php'; ?>
    <div class="container py-2 pb-5 ns-z-main">
        <div class="ns-app-card">
            <div class="ns-app-card-header">
                <i class="fas fa-wand-magic-sparkles fa-3x mb-3"></i>
                <h2 class="mb-1">Live AI meal plan</h2>
                <p class="mb-0 small opacity-90">Suggestions use your latest BMI record (and age/activity if you saved them)</p>
                <div class="mt-2">
                    <span class="insight-chip"><i class="fas fa-bullseye"></i>Goal: <?php echo (int) $dailyGoal; ?> kcal/day</span>
                    <?php if ($has_bmi && !empty($bmi_row['activity_level'])): ?>
                        <span class="insight-chip"><i class="fas fa-person-running"></i><?php echo htmlspecialchars((string) $bmi_row['activity_level']); ?></span>
                    <?php endif; ?>
                </div>
                <?php if ($has_bmi): ?>
                <div class="category-badge">
                    <i class="fas fa-tag me-2"></i>BMI category: <strong><?php echo htmlspecialchars($category); ?></strong>
                    <?php if (!empty($bmi_row['age'])): ?>
                        · Age <?php echo (int) $bmi_row['age']; ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="ns-app-card-body">
                <?php if ($flash !== ''): ?>
                    <div class="alert alert-<?php echo $flashType === 'danger' ? 'danger' : 'success'; ?> py-2"><?php echo htmlspecialchars($flash); ?></div>
                <?php endif; ?>
                <?php if (!$has_bmi): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-calculator fa-4x text-muted mb-3"></i>
                        <h4>Calculate BMI first</h4>
                        <p class="text-muted">We need a saved BMI (and optional age) to tailor meals.</p>
                        <a href="bmi.php" class="btn btn-ai"><i class="fas fa-calculator me-2"></i>Go to BMI</a>
                    </div>
                <?php else: ?>
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
                        <div>
                            <span class="badge <?php echo $aiReady ? 'bg-success' : 'bg-warning text-dark'; ?> me-1">
                                <?php echo $aiReady ? 'Live AI ready' : 'Fallback mode (add API key)'; ?>
                            </span>
                            <small class="text-muted d-block mt-1">Press generate for a fresh AI day plan · not medical advice</small>
                        </div>
                        <button type="button" class="btn btn-ai" id="btnGenerate" onclick="generateAiMeals()">
                            <i class="fas fa-bolt me-2"></i>Generate / refresh AI plan
                        </button>
                    </div>
                    <div id="aiLoading" class="alert alert-info d-none" role="status">
                        <span class="spinner-border spinner-border-sm me-2"></span> Generating personalized suggestions…
                    </div>
                    <div id="aiError" class="alert alert-danger d-none"></div>
                    <div id="aiOutputWrap" class="d-none mb-4">
                        <h5 class="mb-2"><i class="fas fa-robot text-success me-2"></i>AI suggestion</h5>
                        <div id="aiOutput" class="ai-output"></div>
                        <p class="ns-disclaimer small mt-2 mb-0" id="aiMeta"></p>
                    </div>

                    <?php if ($meals && $meals->num_rows > 0): ?>
                    <hr>
                    <h5 class="mb-3"><i class="fas fa-database me-2 text-secondary"></i>Classic database meals (reference)</h5>
                    <?php 
                    $meal_times = [];
                    $total_calories = 0;
                    $meals->data_seek(0);
                    while ($row = $meals->fetch_assoc()) {
                        $meal_times[$row['meal_time']][] = $row;
                        $total_calories += $row['calories'];
                    }
                    ?>
                    <?php foreach (['Breakfast', 'Lunch', 'Dinner', 'Snack'] as $meal_time): ?>
                        <?php if (isset($meal_times[$meal_time])): ?>
                            <div class="meal-time">
                                <div class="d-flex align-items-center mb-3">
                                    <div class="meal-icon me-3">
                                        <?php
                                        if ($meal_time == 'Breakfast') {
                                            echo '<i class="fas fa-sun"></i>';
                                        } elseif ($meal_time == 'Lunch') {
                                            echo '<i class="fas fa-cloud-sun"></i>';
                                        } elseif ($meal_time == 'Dinner') {
                                            echo '<i class="fas fa-moon"></i>';
                                        } else {
                                            echo '<i class="fas fa-cookie"></i>';
                                        }
                                        ?>
                                    </div>
                                    <h4 class="mb-0"><?php echo $meal_time; ?></h4>
                                </div>
                                <?php foreach ($meal_times[$meal_time] as $meal): ?>
                                    <div class="food-item">
                                        <div>
                                            <i class="fas fa-utensils text-success me-2"></i>
                                            <?php echo htmlspecialchars($meal['food']); ?>
                                        </div>
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="calorie-badge"><?php echo (int) $meal['calories']; ?> kcal</span>
                                            <form method="POST" class="m-0">
                                                <input type="hidden" name="food_name" value="<?php echo htmlspecialchars((string) $meal['food'], ENT_QUOTES, 'UTF-8'); ?>">
                                                <input type="hidden" name="food_calories" value="<?php echo (int) $meal['calories']; ?>">
                                                <input type="hidden" name="meal_type" value="<?php echo strtolower($meal_time); ?>">
                                                <button type="submit" name="save_template_to_log" class="btn btn-sm btn-outline-success rounded-pill">
                                                    <i class="fas fa-plus me-1"></i>Log
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                    <div class="total-calories">
                        <h5 class="mb-2">Total (database template)</h5>
                        <h2 class="display-4 mb-0"><?php echo $total_calories; ?> kcal</h2>
                    </div>
                    <?php endif; ?>

                    <p class="ns-disclaimer small mt-3 mb-0">Recommendations are educational. Update BMI when your weight changes so AI stays aligned.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?php if ($has_bmi): ?>
    <script>
        function escapeHtml(s) {
            const d = document.createElement('div');
            d.textContent = s;
            return d.innerHTML;
        }
        function generateAiMeals() {
            const btn = document.getElementById('btnGenerate');
            const load = document.getElementById('aiLoading');
            const err = document.getElementById('aiError');
            const wrap = document.getElementById('aiOutputWrap');
            const out = document.getElementById('aiOutput');
            const meta = document.getElementById('aiMeta');
            err.classList.add('d-none');
            load.classList.remove('d-none');
            btn.disabled = true;
            fetch('meal_ai_api.php', { method: 'POST', credentials: 'same-origin' })
                .then(r => r.json())
                .then(data => {
                    load.classList.add('d-none');
                    btn.disabled = false;
                    if (!data.ok) {
                        err.textContent = data.error || 'Something went wrong';
                        err.classList.remove('d-none');
                        return;
                    }
                    wrap.classList.remove('d-none');
                    out.innerHTML = escapeHtml(data.text).replace(/\n/g, '<br>');
                    if (data.ai_error && data.ai_error !== 'not_configured') {
                        console.warn('[NutriSmart meal AI]', data.ai_error);
                    }
                    meta.textContent = data.source === 'ai'
                        ? 'Source: live AI (OpenAI-compatible).'
                        : 'Fallback or API issue — see ai_config.local.php. ' + (data.ai_error && data.ai_error !== 'not_configured' ? '(' + data.ai_error + ')' : '');
                })
                .catch(() => {
                    load.classList.add('d-none');
                    btn.disabled = false;
                    err.textContent = 'Network error. Try again.';
                    err.classList.remove('d-none');
                });
        }
    </script>
    <?php endif; ?>
</body>
</html>
