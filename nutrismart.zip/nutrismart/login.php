<?php
session_start();
if (isset($_SESSION['user'])) {
    header("Location: dashboard.php");
    exit();
}
include "db.php";

if (!$conn) {
    die("Database connection failed!");
}

if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = md5($_POST['password']);
    $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $_SESSION['user'] = $email;
        $_SESSION['user_name'] = $user['name'];
        header("Location: dashboard.php");
        exit();
    }
    $error = "Invalid email or password!";
    $check_email = $conn->query("SELECT * FROM users WHERE email='$email'");
    if ($check_email->num_rows == 0) {
        $error = "Email not found.";
    } else {
        $error = "Incorrect password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <title>Log in — NutriSmart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
</head>
<body class="ns-body ns-auth-page">
    <div class="ns-auth-blob ns-auth-blob-1" aria-hidden="true"></div>
    <div class="ns-auth-blob ns-auth-blob-2" aria-hidden="true"></div>
    <div class="container position-relative" style="z-index:1;">
        <div class="row justify-content-center">
            <div class="col-md-5 col-lg-4">
                <div class="ns-auth-card shadow-lg">
                    <div class="ns-auth-header">
                        <i class="fas fa-seedling fa-3x mb-3 opacity-90"></i>
                        <h2 class="h3 fw-bold mb-1" style="font-family:var(--ns-font-display);">Welcome back</h2>
                        <p class="mb-0 small opacity-90">NutriSmart · PHC</p>
                    </div>
                    <div class="ns-auth-body">
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger rounded-3 border-0 small"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>
                        <?php if (isset($_GET['registered'])): ?>
                            <div class="alert alert-success rounded-3 border-0 small">Registration successful. You can log in now.</div>
                        <?php endif; ?>

                        <form method="POST" class="ns-input-pill">
                            <div class="mb-3">
                                <label class="form-label small fw-semibold text-secondary">Email</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0 rounded-start-3 text-secondary"><i class="fas fa-envelope"></i></span>
                                    <input type="email" name="email" class="form-control border-start-0 rounded-end-3" placeholder="you@school.edu" required autocomplete="email">
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="form-label small fw-semibold text-secondary">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0 rounded-start-3 text-secondary"><i class="fas fa-lock"></i></span>
                                    <input type="password" name="password" class="form-control border-start-0 rounded-end-3" placeholder="••••••••" required autocomplete="current-password">
                                </div>
                            </div>
                            <button type="submit" name="login" class="btn ns-btn-block">
                                <i class="fas fa-sign-in-alt me-2"></i>Log in
                            </button>
                        </form>

                        <div class="text-center mt-4 pt-2 border-top">
                            <p class="mb-2 small">No account? <a href="register.php" class="fw-semibold text-decoration-none" style="color:var(--ns-teal-dark);">Create one</a></p>
                            <a href="index.php" class="small text-muted text-decoration-none"><i class="fas fa-arrow-left me-1"></i>Back to home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
