<?php
session_start();
include "db.php";

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$email = $_SESSION['user'];
$email_esc = $conn->real_escape_string($email);

$logCols = [];
$logColsRes = $conn->query("SHOW COLUMNS FROM calorie_log");
if ($logColsRes) {
    while ($c = $logColsRes->fetch_assoc()) {
        $logCols[$c['Field']] = true;
    }
}
if (!isset($logCols['meal_type'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN meal_type VARCHAR(20) NULL DEFAULT 'snack' AFTER food");
}
if (!isset($logCols['servings'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN servings DECIMAL(6,2) NULL DEFAULT 1 AFTER calories");
}
if (!isset($logCols['notes'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN notes VARCHAR(255) NULL AFTER servings");
}
if (!isset($logCols['protein_g'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN protein_g DECIMAL(8,2) NULL DEFAULT 0 AFTER notes");
}
if (!isset($logCols['carbs_g'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN carbs_g DECIMAL(8,2) NULL DEFAULT 0 AFTER protein_g");
}
if (!isset($logCols['fat_g'])) {
    $conn->query("ALTER TABLE calorie_log ADD COLUMN fat_g DECIMAL(8,2) NULL DEFAULT 0 AFTER carbs_g");
}
$goalCol = $conn->query("SHOW COLUMNS FROM users LIKE 'daily_calorie_goal'");
if ($goalCol && $goalCol->num_rows === 0) {
    $conn->query("ALTER TABLE users ADD COLUMN daily_calorie_goal INT NULL DEFAULT 2000");
}

$user_res = $conn->query("SELECT *, daily_calorie_goal FROM users WHERE email='$email_esc'");
$user = $user_res ? $user_res->fetch_assoc() : null;
if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$today = date('Y-m-d');
$cal_res = $conn->query("SELECT SUM(calories) AS total FROM calorie_log 
    WHERE user_email='$email_esc' AND DATE(logged_at)='$today'");
$calories_today = $cal_res ? $cal_res->fetch_assoc() : null;
$total_calories = ($calories_today && $calories_today['total'] !== null) ? (int) $calories_today['total'] : 0;
$goal = isset($user['daily_calorie_goal']) && (int) $user['daily_calorie_goal'] > 0 ? (int) $user['daily_calorie_goal'] : 2000;
$remain = max($goal - $total_calories, 0);
$over = max($total_calories - $goal, 0);
$goalPercent = $goal > 0 ? min(($total_calories / $goal) * 100, 100) : 0;

$macro_res = $conn->query("SELECT SUM(protein_g) AS p, SUM(carbs_g) AS c, SUM(fat_g) AS f FROM calorie_log
    WHERE user_email='$email_esc' AND DATE(logged_at)='$today'");
$macro_row = $macro_res ? $macro_res->fetch_assoc() : null;
$proteinToday = $macro_row && $macro_row['p'] !== null ? (float) $macro_row['p'] : 0.0;
$carbsToday = $macro_row && $macro_row['c'] !== null ? (float) $macro_row['c'] : 0.0;
$fatToday = $macro_row && $macro_row['f'] !== null ? (float) $macro_row['f'] : 0.0;

$bmi_res = $conn->query("SELECT bmi, category FROM bmi_records WHERE user_email='$email_esc' ORDER BY id DESC LIMIT 1");
$latest_bmi = $bmi_res ? $bmi_res->fetch_assoc() : null;
$bmi_category_label = $latest_bmi ? $latest_bmi['category'] : null;

$weekRows = [];
$weekSql = $conn->query("
    SELECT DATE(logged_at) AS d, SUM(calories) AS cals
    FROM calorie_log
    WHERE user_email='$email_esc'
      AND DATE(logged_at) BETWEEN DATE_SUB('$today', INTERVAL 6 DAY) AND '$today'
    GROUP BY DATE(logged_at)
    ORDER BY DATE(logged_at) ASC
");
if ($weekSql) {
    while ($wr = $weekSql->fetch_assoc()) {
        $weekRows[$wr['d']] = (int) ($wr['cals'] ?? 0);
    }
}
$weekLabels = [];
$weekValues = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime($today . " -$i day"));
    $weekLabels[] = date('M d', strtotime($d));
    $weekValues[] = isset($weekRows[$d]) ? (int) $weekRows[$d] : 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <title>Dashboard — NutriSmart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
</head>
<body class="ns-body ns-page-app ns-overlay-dark">
    <?php $ns_nav_active = 'dashboard'; include __DIR__ . '/includes/app_nav.php'; ?>

    <div class="container pb-5 ns-z-main">
        <div class="ns-welcome-banner mb-4 position-relative">
            <div class="row align-items-center g-3 position-relative" style="z-index:1;">
                <div class="col-lg-8">
                    <p class="small text-white-50 mb-1 text-uppercase" style="letter-spacing:.08em;">PHC · Your wellness hub</p>
                    <h1 class="h2 mb-2 fw-bold" style="font-family:var(--ns-font-display);">Welcome back, <?php echo htmlspecialchars($user['name']); ?></h1>
                    <p class="mb-0 opacity-90 pe-lg-4">
                        Use the path below: save BMI → unlock meal ideas → chat or log calories. Everything stays aligned to your latest category.
                    </p>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <a href="bmi.php" class="btn btn-light btn-sm rounded-pill fw-semibold text-dark shadow-sm me-2 mb-2 mb-lg-0"><i class="fas fa-ruler-vertical me-1"></i>Update BMI</a>
                    <a href="meal_planner.php" class="btn btn-outline-light btn-sm rounded-pill fw-semibold mb-2 mb-lg-0"><i class="fas fa-wand-magic-sparkles me-1"></i>AI meals</a>
                </div>
            </div>
        </div>

        <div class="ns-journey mb-4">
            <p class="ns-eyebrow mb-2">Your journey</p>
            <div class="row g-3 align-items-center">
                <div class="col-md-4 d-flex align-items-center gap-2">
                    <span class="ns-step-num">1</span>
                    <div><strong class="d-block">BMI</strong><span class="small text-secondary">Height, weight, age → category saved</span></div>
                </div>
                <div class="col-md-4 d-flex align-items-center gap-2">
                    <span class="ns-step-num">2</span>
                    <div><strong class="d-block">Meals</strong><span class="small text-secondary">AI + database ideas for your band</span></div>
                </div>
                <div class="col-md-4 d-flex align-items-center gap-2">
                    <span class="ns-step-num">3</span>
                    <div><strong class="d-block">Learn &amp; log</strong><span class="small text-secondary">Chat (offline guide too) · calorie log</span></div>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-md-6 col-xl-4">
                <div class="ns-tool-card">
                    <div class="ns-tool-icon"><i class="fas fa-ruler-vertical"></i></div>
                    <h2 class="h5 fw-bold" style="font-family:var(--ns-font-display);">BMI calculator</h2>
                    <p class="small text-secondary flex-grow-1">Compute BMI, optional BMR hints, and save your category for meal matching.</p>
                    <a href="bmi.php" class="btn ns-btn-go text-decoration-none"><span>Open tool</span><i class="fas fa-arrow-right ms-2"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="ns-tool-card">
                    <div class="ns-tool-icon"><i class="fas fa-clock-rotate-left"></i></div>
                    <h2 class="h5 fw-bold" style="font-family:var(--ns-font-display);">BMI history</h2>
                    <p class="small text-secondary flex-grow-1">Charts and table of past readings—see trends over time.</p>
                    <a href="bmi_history.php" class="btn ns-btn-go text-decoration-none"><span>View history</span><i class="fas fa-arrow-right ms-2"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="ns-tool-card">
                    <div class="ns-tool-icon"><i class="fas fa-utensils"></i></div>
                    <h2 class="h5 fw-bold" style="font-family:var(--ns-font-display);">Meal planner</h2>
                    <p class="small text-secondary flex-grow-1">Live AI day plan when API allows, plus classic meal templates.</p>
                    <a href="meal_planner.php" class="btn ns-btn-go text-decoration-none"><span>Open planner</span><i class="fas fa-arrow-right ms-2"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="ns-tool-card">
                    <div class="ns-tool-icon"><i class="fas fa-robot"></i></div>
                    <h2 class="h5 fw-bold" style="font-family:var(--ns-font-display);">Nutrition chat</h2>
                    <p class="small text-secondary flex-grow-1">Live AI or a large offline knowledge base—type <strong>help</strong> for topics.</p>
                    <a href="chatbot.php" class="btn ns-btn-go text-decoration-none"><span>Open chat</span><i class="fas fa-arrow-right ms-2"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="ns-tool-card">
                    <div class="ns-tool-icon"><i class="fas fa-fire-flame-curved"></i></div>
                    <h2 class="h5 fw-bold" style="font-family:var(--ns-font-display);">Calorie log</h2>
                    <p class="small text-secondary flex-grow-1">Multi-select foods and servings—build awareness without scanning photos.</p>
                    <a href="calorie_tracker.php" class="btn ns-btn-go text-decoration-none"><span>Log food</span><i class="fas fa-arrow-right ms-2"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-xl-4">
                <div class="ns-tool-card">
                    <div class="ns-tool-icon"><i class="fas fa-lightbulb"></i></div>
                    <h2 class="h5 fw-bold" style="font-family:var(--ns-font-display);">Daily tip</h2>
                    <p class="small text-secondary flex-grow-1">Random campus-friendly wellness nudge—one tap.</p>
                    <button type="button" class="btn ns-btn-go border-0" onclick="showDailyTip()"><span>Get a tip</span><i class="fas fa-arrow-right ms-2"></i></button>
                </div>
            </div>
        </div>

        <div class="ns-stats-panel mb-5">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h2 class="h5 fw-bold mb-0" style="font-family:var(--ns-font-display);">Today at a glance</h2>
                <span class="badge rounded-pill bg-light text-secondary border">Reference only</span>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="ns-stat-icon"><i class="fas fa-fire fa-lg"></i></div>
                        <div>
                            <small class="text-muted d-block">Calories logged</small>
                            <span class="h4 mb-0 fw-bold"><?php echo $total_calories; ?> <small class="text-muted fs-6 fw-normal">/ <?php echo $goal; ?> kcal</small></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="ns-stat-icon"><i class="fas fa-weight-scale fa-lg"></i></div>
                        <div>
                            <small class="text-muted d-block">Latest BMI</small>
                            <span class="h4 mb-0 fw-bold"><?php echo $latest_bmi ? number_format((float) $latest_bmi['bmi'], 1) : '—'; ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-3">
                        <div class="ns-stat-icon"><i class="fas fa-tags fa-lg"></i></div>
                        <div>
                            <small class="text-muted d-block">BMI category</small>
                            <?php if ($bmi_category_label): ?>
                                <span class="h6 mb-0 fw-bold text-success"><?php echo htmlspecialchars($bmi_category_label); ?></span>
                            <?php else: ?>
                                <a href="bmi.php" class="small fw-semibold">Add a reading</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="progress mt-3" style="height:10px;">
                <div class="progress-bar bg-success" style="width: <?php echo $goalPercent; ?>%"></div>
            </div>
            <p class="small mb-0 mt-2 text-secondary"><?php echo $over > 0 ? "Over target by $over kcal." : "$remain kcal remaining to goal."; ?></p>
            <div class="row g-3 mt-1">
                <div class="col-md-4"><div class="p-2 bg-light rounded-3 border"><small class="text-muted d-block">Protein</small><strong><?php echo number_format($proteinToday, 1); ?> g</strong></div></div>
                <div class="col-md-4"><div class="p-2 bg-light rounded-3 border"><small class="text-muted d-block">Carbs</small><strong><?php echo number_format($carbsToday, 1); ?> g</strong></div></div>
                <div class="col-md-4"><div class="p-2 bg-light rounded-3 border"><small class="text-muted d-block">Fat</small><strong><?php echo number_format($fatToday, 1); ?> g</strong></div></div>
            </div>
            <div class="mt-3 p-2 bg-white rounded-3 border">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <small class="text-muted">7-day calorie trend</small>
                    <a href="calorie_tracker.php" class="small text-decoration-none fw-semibold">Open full log</a>
                </div>
                <canvas id="weekTrend" height="85"></canvas>
            </div>
            <p class="ns-disclaimer mb-0 mt-3">Educational only. Meal suggestions use your latest saved BMI category.</p>
        </div>
    </div>

    <button type="button" class="ns-fab d-flex align-items-center justify-content-center" data-bs-toggle="modal" data-bs-target="#guideModal" title="Full system guide" aria-label="Open system guide">
        <i class="fas fa-map"></i>
        <span class="ns-fab-label">How everything works</span>
    </button>

    <div class="modal fade ns-modal-guide" id="guideModal" tabindex="-1" aria-labelledby="guideModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable modal-lg modal-dialog-centered">
            <div class="modal-content shadow-lg">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold" id="guideModal"><i class="fas fa-book-open me-2"></i>NutriSmart — full system guide</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <p class="text-secondary small mb-4">Follow these in order the first time. You can return to any step anytime.</p>
                    <ul class="ns-guide-list">
                        <li><span class="bi-num">1</span><div><strong>Register &amp; log in</strong><br><span class="small text-secondary">Create one account per person. Your email is your login.</span></div></li>
                        <li><span class="bi-num">2</span><div><strong>BMI calculator</strong><br><span class="small text-secondary">Enter weight (kg), height (cm), optional age &amp; activity. Save—this sets your category for meals.</span></div></li>
                        <li><span class="bi-num">3</span><div><strong>BMI history</strong><br><span class="small text-secondary">See past values and a chart. Update BMI when weight changes so tools stay accurate.</span></div></li>
                        <li><span class="bi-num">4</span><div><strong>Meal planner</strong><br><span class="small text-secondary">Generate AI suggestions (needs API quota) or use database templates by category. Filipino-friendly ideas included.</span></div></li>
                        <li><span class="bi-num">5</span><div><strong>Nutrition chat</strong><br><span class="small text-secondary">Ask about habits, BMI, Pinoy food, hydration. Type <strong>help</strong> for offline topics if live AI is off.</span></div></li>
                        <li><span class="bi-num">6</span><div><strong>Calorie log</strong><br><span class="small text-secondary">Select multiple foods and servings for today’s total. Optional awareness tool—not medical tracking.</span></div></li>
                    </ul>
                    <div class="alert alert-light border mt-3 mb-0 small">
                        <i class="fas fa-triangle-exclamation text-warning me-1"></i> Not for diagnosis. For allergies, diabetes, pregnancy, or disorders—see a licensed professional.
                    </div>
                </div>
                <div class="modal-footer border-0 bg-light">
                    <a href="index.php#scope" class="btn btn-outline-secondary rounded-pill">Read scope &amp; limits</a>
                    <button type="button" class="btn ns-btn-primary rounded-pill" data-bs-dismiss="modal">Got it</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="tipModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0 ns-modal-guide">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-lightbulb me-2"></i>Daily wellness tip</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p id="dailyTip" class="mb-0 lead fs-6 text-secondary"></p>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const tips = [
            "Pair ulam with a full cup of vegetables at least once a day—fiber slows energy dips between classes.",
            "Carry a refillable bottle; mild dehydration often feels like hunger during long lectures.",
            "If dinner is late, add a protein + fruit snack mid-afternoon to avoid over-ordering fast food after campus hours.",
            "Aim for consistent meal times on school days so your energy matches your class blocks.",
            "Choose one new whole grain (brown rice, oats, whole-wheat bread) each week instead of changing everything at once.",
            "After computing BMI, open Meal Planner so suggestions stay aligned with your category.",
            "Sleep 7–9 hours when possible—rest changes appetite signals more than most quick fixes.",
            "When stressed, try a 10-minute walk before deciding what to eat.",
            "Read labels for serving size; 'healthy' snacks still count toward your daily energy budget.",
            "Use the chat for 'why' questions and the planner for 'what to eat' structure—they work best together."
        ];
        function showDailyTip() {
            const t = tips[Math.floor(Math.random() * tips.length)];
            document.getElementById('dailyTip').textContent = t;
            new bootstrap.Modal(document.getElementById('tipModal')).show();
        }
        const weekCtx = document.getElementById('weekTrend');
        if (weekCtx && typeof Chart !== 'undefined') {
            new Chart(weekCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($weekLabels); ?>,
                    datasets: [{
                        label: 'Calories',
                        data: <?php echo json_encode($weekValues); ?>,
                        borderColor: '#0d9488',
                        backgroundColor: 'rgba(13,148,136,.12)',
                        borderWidth: 3,
                        tension: .35,
                        fill: true,
                        pointRadius: 3
                    }]
                },
                options: {
                    responsive: true,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true } }
                }
            });
        }
    </script>
</body>
</html>
