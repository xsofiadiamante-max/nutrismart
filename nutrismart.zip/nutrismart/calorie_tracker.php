<?php
session_start();
include "db.php";

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

function nutrismart_ensure_calorie_columns(mysqli $conn): void
{
    $cols = [];
    $res = $conn->query("SHOW COLUMNS FROM calorie_log");
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $cols[$row['Field']] = true;
        }
    }
    if (!isset($cols['meal_type'])) {
        $conn->query("ALTER TABLE calorie_log ADD COLUMN meal_type VARCHAR(20) NULL DEFAULT 'snack' AFTER food");
    }
    if (!isset($cols['servings'])) {
        $conn->query("ALTER TABLE calorie_log ADD COLUMN servings DECIMAL(6,2) NULL DEFAULT 1 AFTER calories");
    }
    if (!isset($cols['notes'])) {
        $conn->query("ALTER TABLE calorie_log ADD COLUMN notes VARCHAR(255) NULL AFTER servings");
    }
    if (!isset($cols['protein_g'])) {
        $conn->query("ALTER TABLE calorie_log ADD COLUMN protein_g DECIMAL(8,2) NULL DEFAULT 0 AFTER notes");
    }
    if (!isset($cols['carbs_g'])) {
        $conn->query("ALTER TABLE calorie_log ADD COLUMN carbs_g DECIMAL(8,2) NULL DEFAULT 0 AFTER protein_g");
    }
    if (!isset($cols['fat_g'])) {
        $conn->query("ALTER TABLE calorie_log ADD COLUMN fat_g DECIMAL(8,2) NULL DEFAULT 0 AFTER carbs_g");
    }
}

function nutrismart_ensure_user_goal_column(mysqli $conn): void
{
    $chk = $conn->query("SHOW COLUMNS FROM users LIKE 'daily_calorie_goal'");
    if ($chk && $chk->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN daily_calorie_goal INT NULL DEFAULT 2000");
    }
}

function nutrismart_safe_meal(string $meal): string
{
    $allowed = ['breakfast', 'lunch', 'dinner', 'snack'];
    $meal = strtolower(trim($meal));
    return in_array($meal, $allowed, true) ? $meal : 'snack';
}

function nutrismart_food_macro_columns(mysqli $conn): array
{
    $cols = ['protein' => null, 'carbs' => null, 'fat' => null];
    $res = $conn->query("SHOW COLUMNS FROM foods");
    if (!$res) {
        return $cols;
    }
    $map = [];
    while ($row = $res->fetch_assoc()) {
        $map[strtolower((string) $row['Field'])] = (string) $row['Field'];
    }
    foreach (['protein_g', 'protein', 'protein_grams'] as $c) {
        if (isset($map[$c])) { $cols['protein'] = $map[$c]; break; }
    }
    foreach (['carbs_g', 'carbs', 'carbohydrates', 'carbohydrate_g'] as $c) {
        if (isset($map[$c])) { $cols['carbs'] = $map[$c]; break; }
    }
    foreach (['fat_g', 'fat', 'fats'] as $c) {
        if (isset($map[$c])) { $cols['fat'] = $map[$c]; break; }
    }
    return $cols;
}

nutrismart_ensure_calorie_columns($conn);
nutrismart_ensure_user_goal_column($conn);
$foodMacroCols = nutrismart_food_macro_columns($conn);

$email = $_SESSION['user'];
$email_esc = $conn->real_escape_string($email);
$user_res = $conn->query("SELECT name, daily_calorie_goal FROM users WHERE email='$email_esc' LIMIT 1");
$user = $user_res ? $user_res->fetch_assoc() : null;
if (!$user) {
    session_destroy();
    header("Location: login.php");
    exit();
}

$selectedDate = isset($_GET['date']) ? trim((string) $_GET['date']) : date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) {
    $selectedDate = date('Y-m-d');
}

$flash = '';
$flash_type = 'success';

if (isset($_POST['save_goal'])) {
    $goal = isset($_POST['daily_goal']) ? (int) $_POST['daily_goal'] : 2000;
    $goal = max(1000, min(6000, $goal));
    $conn->query("UPDATE users SET daily_calorie_goal=$goal WHERE email='$email_esc' LIMIT 1");
    $user['daily_calorie_goal'] = $goal;
    $flash = 'Daily calorie target updated.';
}

if (isset($_POST['delete_log'])) {
    $id = isset($_POST['log_id']) ? (int) $_POST['log_id'] : 0;
    if ($id > 0) {
        $conn->query("DELETE FROM calorie_log WHERE id=$id AND user_email='$email_esc' LIMIT 1");
        $flash = 'Log entry removed.';
    }
}

$hasFoodId = false;
$chk = $conn->query("SHOW COLUMNS FROM foods LIKE 'id'");
if ($chk && $chk->num_rows > 0) {
    $hasFoodId = true;
}

if (isset($_POST['add'])) {
    $food = isset($_POST['food']) ? trim((string) $_POST['food']) : '';
    $food_esc = $conn->real_escape_string($food);
    $custom_calories = isset($_POST['custom_calories']) ? (int) $_POST['custom_calories'] : 0;
    $servings = isset($_POST['servings']) ? (float) $_POST['servings'] : 1;
    $servings = max(0.25, min(10, $servings));
    $meal_type = nutrismart_safe_meal(isset($_POST['meal_type']) ? (string) $_POST['meal_type'] : 'snack');
    $meal_type_esc = $conn->real_escape_string($meal_type);
    $notes = isset($_POST['notes']) ? trim((string) $_POST['notes']) : '';
    $notes_esc = $conn->real_escape_string(substr($notes, 0, 255));
    $protein = max(0, (float) (isset($_POST['protein_g']) ? $_POST['protein_g'] : 0));
    $carbs = max(0, (float) (isset($_POST['carbs_g']) ? $_POST['carbs_g'] : 0));
    $fat = max(0, (float) (isset($_POST['fat_g']) ? $_POST['fat_g'] : 0));

    if ($food_esc === 'custom') {
        $calories = max(0, $custom_calories);
        $food_name = isset($_POST['custom_food']) ? trim((string) $_POST['custom_food']) : 'Custom';
        if ($food_name === '') {
            $food_name = 'Custom';
        }
        $food_name_esc = $conn->real_escape_string($food_name);
        $entry_cal = (int) round($calories * $servings);
        $p = round($protein * $servings, 2);
        $c = round($carbs * $servings, 2);
        $f = round($fat * $servings, 2);
        $conn->query("INSERT INTO calorie_log (user_email, food, meal_type, calories, servings, notes, protein_g, carbs_g, fat_g) VALUES ('$email_esc', '$food_name_esc', '$meal_type_esc', '$entry_cal', '$servings', " . ($notes !== '' ? "'$notes_esc'" : 'NULL') . ", '$p', '$c', '$f')");
        $flash = 'Custom item added.';
    } elseif ($food_esc !== '') {
        $select = "SELECT calories";
        if ($foodMacroCols['protein']) { $select .= ", `".$conn->real_escape_string($foodMacroCols['protein'])."` AS protein_val"; }
        if ($foodMacroCols['carbs']) { $select .= ", `".$conn->real_escape_string($foodMacroCols['carbs'])."` AS carbs_val"; }
        if ($foodMacroCols['fat']) { $select .= ", `".$conn->real_escape_string($foodMacroCols['fat'])."` AS fat_val"; }
        $r = $conn->query("$select FROM foods WHERE name='$food_esc' LIMIT 1");
        $row = $r ? $r->fetch_assoc() : null;
        if ($row) {
            $entry_cal = (int) round(((int) $row['calories']) * $servings);
            $p = round(((float) ($row['protein_val'] ?? 0)) * $servings, 2);
            $c = round(((float) ($row['carbs_val'] ?? 0)) * $servings, 2);
            $f = round(((float) ($row['fat_val'] ?? 0)) * $servings, 2);
            $conn->query("INSERT INTO calorie_log (user_email, food, meal_type, calories, servings, notes, protein_g, carbs_g, fat_g) VALUES ('$email_esc', '$food_esc', '$meal_type_esc', '$entry_cal', '$servings', " . ($notes !== '' ? "'$notes_esc'" : 'NULL') . ", '$p', '$c', '$f')");
            $flash = 'Food added to your log.';
        } else {
            $flash = 'Selected food was not found.';
            $flash_type = 'danger';
        }
    } else {
        $flash = 'Pick a food first.';
        $flash_type = 'danger';
    }
}

if (isset($_POST['batch_add']) && isset($_POST['pick']) && is_array($_POST['pick'])) {
    $added = 0;
    $meal_type = nutrismart_safe_meal(isset($_POST['batch_meal_type']) ? (string) $_POST['batch_meal_type'] : 'snack');
    $meal_type_esc = $conn->real_escape_string($meal_type);
    foreach ($_POST['pick'] as $key => $on) {
        $qty = isset($_POST['qty'][$key]) ? (float) $_POST['qty'][$key] : 1;
        $qty = max(0.25, min(10, $qty));
        $select = "SELECT name, calories";
        if ($foodMacroCols['protein']) { $select .= ", `".$conn->real_escape_string($foodMacroCols['protein'])."` AS protein_val"; }
        if ($foodMacroCols['carbs']) { $select .= ", `".$conn->real_escape_string($foodMacroCols['carbs'])."` AS carbs_val"; }
        if ($foodMacroCols['fat']) { $select .= ", `".$conn->real_escape_string($foodMacroCols['fat'])."` AS fat_val"; }
        if ($hasFoodId) {
            $fid = (int) $key;
            if ($fid < 1) {
                continue;
            }
            $r = $conn->query("$select FROM foods WHERE id=$fid LIMIT 1");
        } else {
            $name_esc = $conn->real_escape_string((string) $key);
            $r = $conn->query("$select FROM foods WHERE name='$name_esc' LIMIT 1");
        }
        $row = $r ? $r->fetch_assoc() : null;
        if (!$row) {
            continue;
        }
        $name_ins = $conn->real_escape_string($row['name']);
        $cals = (int) round(((int) $row['calories']) * $qty);
        $p = round(((float) ($row['protein_val'] ?? 0)) * $qty, 2);
        $c = round(((float) ($row['carbs_val'] ?? 0)) * $qty, 2);
        $f = round(((float) ($row['fat_val'] ?? 0)) * $qty, 2);
        $conn->query("INSERT INTO calorie_log (user_email, food, meal_type, calories, servings, protein_g, carbs_g, fat_g) VALUES ('$email_esc', '$name_ins', '$meal_type_esc', '$cals', '$qty', '$p', '$c', '$f')");
        $added++;
    }
    if ($added > 0) {
        $flash = $added . ' food item(s) added.';
    } else {
        $flash = 'No food selected.';
        $flash_type = 'danger';
    }
}

$goal = isset($user['daily_calorie_goal']) && (int) $user['daily_calorie_goal'] > 0 ? (int) $user['daily_calorie_goal'] : 2000;

$date_esc = $conn->real_escape_string($selectedDate);
$logs = $conn->query("SELECT id, food, meal_type, calories, servings, notes, protein_g, carbs_g, fat_g, logged_at FROM calorie_log WHERE user_email='$email_esc' AND DATE(logged_at)='$date_esc' ORDER BY logged_at DESC, id DESC");
$foods = $conn->query("SELECT * FROM foods ORDER BY name");

$entries = [];
$total = 0;
$proteinTotal = 0.0;
$carbsTotal = 0.0;
$fatTotal = 0.0;
$mealTotals = ['breakfast' => 0, 'lunch' => 0, 'dinner' => 0, 'snack' => 0];
if ($logs && $logs->num_rows > 0) {
    while ($row = $logs->fetch_assoc()) {
        $entries[] = $row;
        $cal = (int) $row['calories'];
        $total += $cal;
        $proteinTotal += (float) ($row['protein_g'] ?? 0);
        $carbsTotal += (float) ($row['carbs_g'] ?? 0);
        $fatTotal += (float) ($row['fat_g'] ?? 0);
        $m = nutrismart_safe_meal((string) ($row['meal_type'] ?? 'snack'));
        $mealTotals[$m] += $cal;
    }
}
$percentage = $goal > 0 ? min(($total / $goal) * 100, 100) : 0;
$remaining = max($goal - $total, 0);
$overBy = max($total - $goal, 0);

$weekRows = [];
$weekSql = $conn->query("
    SELECT DATE(logged_at) AS d, SUM(calories) AS cals
    FROM calorie_log
    WHERE user_email='$email_esc'
      AND DATE(logged_at) BETWEEN DATE_SUB('$date_esc', INTERVAL 6 DAY) AND '$date_esc'
    GROUP BY DATE(logged_at)
    ORDER BY DATE(logged_at) ASC
");
if ($weekSql) {
    while ($wr = $weekSql->fetch_assoc()) {
        $weekRows[$wr['d']] = (int) ($wr['cals'] ?? 0);
    }
}
$weekLabels = [];
$weekValues = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime($selectedDate . " -$i day"));
    $weekLabels[] = date('M d', strtotime($d));
    $weekValues[] = isset($weekRows[$d]) ? (int) $weekRows[$d] : 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0f766e">
    <title>Calorie Tracker - NutriSmart</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/nutrismart.css">
    <style>
        .calorie-progress, .tracker-card {
            background: #fff;
            border-radius: 16px;
            padding: 1rem;
            border: 1px solid rgba(15, 23, 42, 0.06);
            box-shadow: 0 8px 24px rgba(15, 23, 42, 0.06);
        }
        .tracker-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: .75rem;
        }
        .tracker-stat {
            border-radius: 14px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: .75rem;
        }
        .meal-chip {
            border-radius: 999px;
            font-size: .75rem;
            padding: .25rem .6rem;
            font-weight: 700;
            text-transform: capitalize;
            background: rgba(13, 148, 136, 0.12);
            color: #0f766e;
        }
        .progress-ring { position: relative; width: 140px; height: 140px; margin: 0 auto .75rem; }
        .progress-value {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--ns-teal-dark);
        }
        .food-log-item {
            background: #fff;
            border-radius: 14px;
            padding: 12px 14px;
            margin-bottom: 10px;
            border: 1px solid rgba(15, 23, 42, 0.07);
            display: flex;
            justify-content: space-between;
            gap: .75rem;
            align-items: center;
        }
        .food-time { color: #64748b; font-size: .82rem; }
        .calorie-number {
            border-radius: 999px;
            background: var(--ns-gradient);
            color: #fff;
            padding: .35rem .75rem;
            font-weight: 700;
            font-size: .86rem;
            white-space: nowrap;
        }
        .search-box, .food-pick-row input[type="number"] { border-radius: 10px !important; }
        .food-pick-row {
            display: grid;
            grid-template-columns: 26px 1fr 78px;
            gap: .65rem;
            align-items: center;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: .5rem .65rem;
            margin-bottom: .45rem;
            background: #fff;
        }
        .batch-scroll { max-height: 300px; overflow-y: auto; padding-right: 4px; }
        .macro-box {
            border-radius: 14px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: .8rem;
            text-align: center;
        }
    </style>
</head>
<body class="ns-body ns-page-app ns-overlay-dark">
    <?php $ns_nav_active = 'calories'; include __DIR__ . '/includes/app_nav.php'; ?>
    <div class="container py-2 pb-5 ns-z-main">

        <div class="ns-app-card">
            <div class="ns-app-card-header">
                <i class="fas fa-fire-flame-curved fa-2x mb-2"></i>
                <h2 class="mb-1">Real daily calorie tracker</h2>
                <p class="mb-0 small opacity-90">Track meals, servings, notes, and target progress in one place.</p>
            </div>
            <div class="ns-app-card-body">
                <?php if ($flash !== ''): ?>
                    <div class="alert alert-<?php echo $flash_type === 'danger' ? 'danger' : 'success'; ?> py-2"><?php echo htmlspecialchars($flash); ?></div>
                <?php endif; ?>

                <form method="GET" class="row g-2 align-items-end mb-3">
                    <div class="col-md-4">
                        <label class="form-label small text-muted mb-1">Log date</label>
                        <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($selectedDate, ENT_QUOTES, 'UTF-8'); ?>">
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-outline-success w-100" type="submit">View</button>
                    </div>
                    <div class="col-md-6 text-md-end">
                        <small class="text-muted">Showing records for <strong><?php echo htmlspecialchars(date('M d, Y', strtotime($selectedDate)), ENT_QUOTES, 'UTF-8'); ?></strong></small>
                    </div>
                </form>

                <div class="row g-3 mb-3">
                    <div class="col-lg-5">
                        <div class="calorie-progress h-100 text-center">
                            <div class="progress-ring">
                                <svg width="140" height="140">
                                    <circle stroke="#e5e7eb" stroke-width="10" fill="transparent" r="56" cx="70" cy="70"></circle>
                                    <circle stroke="#0d9488" stroke-width="10" fill="transparent" r="56" cx="70" cy="70"
                                        style="stroke-dasharray:352;stroke-dashoffset:<?php echo 352 - (352 * $percentage / 100); ?>;"></circle>
                                </svg>
                                <div class="progress-value"><?php echo (int) round($percentage); ?>%</div>
                            </div>
                            <h4 class="mb-1"><?php echo $total; ?> / <?php echo $goal; ?> kcal</h4>
                            <p class="text-muted mb-0 small">
                                <?php echo $overBy > 0 ? 'Over by ' . $overBy . ' kcal today' : $remaining . ' kcal remaining'; ?>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="tracker-card h-100">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="mb-0"><i class="fas fa-bullseye text-success me-2"></i>Daily target</h6>
                            </div>
                            <form method="POST" class="row g-2 align-items-end mb-3">
                                <div class="col-sm-8">
                                    <label class="form-label small text-muted mb-1">Goal kcal/day</label>
                                    <input type="number" name="daily_goal" class="form-control" min="1000" max="6000" value="<?php echo (int) $goal; ?>" required>
                                </div>
                                <div class="col-sm-4">
                                    <button type="submit" name="save_goal" class="btn ns-btn-primary w-100">Save</button>
                                </div>
                            </form>
                            <div class="tracker-grid">
                                <div class="tracker-stat"><small class="text-muted d-block">Breakfast</small><strong><?php echo $mealTotals['breakfast']; ?> kcal</strong></div>
                                <div class="tracker-stat"><small class="text-muted d-block">Lunch</small><strong><?php echo $mealTotals['lunch']; ?> kcal</strong></div>
                                <div class="tracker-stat"><small class="text-muted d-block">Dinner</small><strong><?php echo $mealTotals['dinner']; ?> kcal</strong></div>
                                <div class="tracker-stat"><small class="text-muted d-block">Snacks</small><strong><?php echo $mealTotals['snack']; ?> kcal</strong></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-4"><div class="macro-box"><small class="text-muted d-block">Protein</small><strong><?php echo number_format($proteinTotal, 1); ?> g</strong></div></div>
                    <div class="col-md-4"><div class="macro-box"><small class="text-muted d-block">Carbs</small><strong><?php echo number_format($carbsTotal, 1); ?> g</strong></div></div>
                    <div class="col-md-4"><div class="macro-box"><small class="text-muted d-block">Fat</small><strong><?php echo number_format($fatTotal, 1); ?> g</strong></div></div>
                </div>

                <div class="tracker-card mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <h6 class="mb-0"><i class="fas fa-chart-line text-success me-2"></i>7-day calorie trend</h6>
                        <small class="text-muted">ending <?php echo htmlspecialchars(date('M d', strtotime($selectedDate)), ENT_QUOTES, 'UTF-8'); ?></small>
                    </div>
                    <canvas id="weekChart" height="90"></canvas>
                </div>

                <div class="row g-3">
                    <div class="col-lg-6">
                        <div class="tracker-card h-100">
                            <h5 class="mb-2"><i class="fas fa-layer-group text-success me-2"></i>Quick batch add</h5>
                            <p class="small text-muted mb-2">Select multiple foods and set servings for one meal type.</p>
                            <form method="POST" id="batchForm">
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <select name="batch_meal_type" class="form-select">
                                            <option value="breakfast">Breakfast</option>
                                            <option value="lunch">Lunch</option>
                                            <option value="dinner">Dinner</option>
                                            <option value="snack" selected>Snack</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <input type="text" class="form-control search-box" id="foodSearch" placeholder="Filter foods..." autocomplete="off">
                                    </div>
                                </div>
                                <div class="batch-scroll">
                                    <?php
                                    if ($foods && $foods->num_rows > 0) {
                                        $foods->data_seek(0);
                                        $pickRow = 0;
                                        while ($food = $foods->fetch_assoc()) {
                                            $pickRow++;
                                            $key = $hasFoodId ? (int) $food['id'] : (string) $food['name'];
                                            $keyAttr = htmlspecialchars((string) $key, ENT_QUOTES, 'UTF-8');
                                            $fname = htmlspecialchars($food['name'], ENT_QUOTES, 'UTF-8');
                                            $fcal = (int) $food['calories'];
                                            $rowId = 'fpick_' . $pickRow;
                                            ?>
                                            <div class="food-pick-row js-food-row" data-name="<?php echo htmlspecialchars(strtolower($food['name']), ENT_QUOTES, 'UTF-8'); ?>">
                                                <input class="form-check-input mt-0" type="checkbox" name="pick[<?php echo $keyAttr; ?>]" value="1" id="<?php echo $rowId; ?>">
                                                <label class="form-check-label mb-0" for="<?php echo $rowId; ?>">
                                                    <?php echo $fname; ?> <small class="text-muted">(<?php echo $fcal; ?> kcal)</small>
                                                </label>
                                                <input type="number" step="0.25" name="qty[<?php echo $keyAttr; ?>]" value="1" min="0.25" max="10" aria-label="Servings for <?php echo $fname; ?>">
                                            </div>
                                            <?php
                                        }
                                    } else {
                                        echo '<p class="small text-muted mb-0">No foods available in database.</p>';
                                    }
                                    ?>
                                </div>
                                <button type="submit" name="batch_add" class="btn ns-btn-primary w-100 mt-2">Add selected</button>
                            </form>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="tracker-card h-100">
                            <h5 class="mb-2"><i class="fas fa-plus-circle text-success me-2"></i>Add single item</h5>
                            <form method="POST">
                                <div class="row g-2">
                                    <div class="col-6">
                                        <label class="form-label small text-muted mb-1">Meal type</label>
                                        <select name="meal_type" class="form-select">
                                            <option value="breakfast">Breakfast</option>
                                            <option value="lunch">Lunch</option>
                                            <option value="dinner">Dinner</option>
                                            <option value="snack" selected>Snack</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small text-muted mb-1">Servings</label>
                                        <input type="number" step="0.25" name="servings" class="form-control" value="1" min="0.25" max="10" required>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <label class="form-label small text-muted mb-1">Food</label>
                                    <select name="food" class="form-select" id="foodSelect" onchange="toggleCustomFood()">
                                        <option value="">Choose a food...</option>
                                        <?php
                                        if ($foods) {
                                            $foods->data_seek(0);
                                            while ($food = $foods->fetch_assoc()):
                                        ?>
                                            <option value="<?php echo htmlspecialchars($food['name'], ENT_QUOTES, 'UTF-8'); ?>">
                                                <?php echo htmlspecialchars($food['name'], ENT_QUOTES, 'UTF-8'); ?> (<?php echo (int) $food['calories']; ?> kcal)
                                            </option>
                                        <?php endwhile; } ?>
                                        <option value="custom">+ Custom food</option>
                                    </select>
                                </div>
                                <div id="customFoodDiv" class="mt-2" style="display:none;">
                                    <div class="row g-2">
                                        <div class="col-7"><input type="text" name="custom_food" class="form-control" placeholder="Custom food name"></div>
                                        <div class="col-5"><input type="number" name="custom_calories" class="form-control" placeholder="kcal/serving" min="0"></div>
                                    </div>
                                </div>
                                <div class="mt-2">
                                    <label class="form-label small text-muted mb-1">Optional note</label>
                                    <input type="text" name="notes" maxlength="255" class="form-control" placeholder="e.g. post-workout, no sugar">
                                </div>
                                <div id="customMacroDiv" class="mt-2" style="display:none;">
                                    <label class="form-label small text-muted mb-1">Custom macros per serving (optional)</label>
                                    <div class="row g-2">
                                        <div class="col-4"><input type="number" step="0.1" min="0" name="protein_g" class="form-control" placeholder="Protein g"></div>
                                        <div class="col-4"><input type="number" step="0.1" min="0" name="carbs_g" class="form-control" placeholder="Carbs g"></div>
                                        <div class="col-4"><input type="number" step="0.1" min="0" name="fat_g" class="form-control" placeholder="Fat g"></div>
                                    </div>
                                </div>
                                <button type="submit" name="add" class="btn ns-btn-primary w-100 mt-3">Add to log</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="tracker-card mt-3">
                    <h5 class="mb-3"><i class="fas fa-list-check me-2 text-success"></i>Today&apos;s entries (<?php echo count($entries); ?>)</h5>
                    <?php if (count($entries) > 0): ?>
                        <?php foreach ($entries as $row): ?>
                            <?php
                            $meal = nutrismart_safe_meal((string) ($row['meal_type'] ?? 'snack'));
                            $serv = isset($row['servings']) ? (float) $row['servings'] : 1;
                            ?>
                            <div class="food-log-item">
                                <div>
                                    <div class="d-flex align-items-center gap-2 mb-1">
                                        <strong><?php echo htmlspecialchars((string) $row['food'], ENT_QUOTES, 'UTF-8'); ?></strong>
                                        <span class="meal-chip"><?php echo htmlspecialchars($meal, ENT_QUOTES, 'UTF-8'); ?></span>
                                    </div>
                                    <div class="food-time">
                                        <i class="far fa-clock me-1"></i><?php echo date('h:i A', strtotime((string) $row['logged_at'])); ?>
                                        · <?php echo rtrim(rtrim(number_format($serv, 2), '0'), '.'); ?> serving(s)
                                        <?php if (!empty($row['notes'])): ?>· <?php echo htmlspecialchars((string) $row['notes'], ENT_QUOTES, 'UTF-8'); ?><?php endif; ?>
                                        <?php
                                            $pp = (float) ($row['protein_g'] ?? 0);
                                            $cc = (float) ($row['carbs_g'] ?? 0);
                                            $ff = (float) ($row['fat_g'] ?? 0);
                                        ?>
                                        <?php if ($pp > 0 || $cc > 0 || $ff > 0): ?>· P <?php echo number_format($pp, 1); ?>g / C <?php echo number_format($cc, 1); ?>g / F <?php echo number_format($ff, 1); ?>g<?php endif; ?>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="calorie-number"><?php echo (int) $row['calories']; ?> kcal</span>
                                    <form method="POST" onsubmit="return confirm('Delete this entry?');" class="m-0">
                                        <input type="hidden" name="log_id" value="<?php echo (int) $row['id']; ?>">
                                        <button type="submit" name="delete_log" class="btn btn-sm btn-outline-danger rounded-pill">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-utensils fa-2x mb-2"></i>
                            <p class="mb-0">No entries yet. Start by adding your first meal.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleCustomFood() {
            const select = document.getElementById('foodSelect');
            const custom = document.getElementById('customFoodDiv');
            const customMacro = document.getElementById('customMacroDiv');
            custom.style.display = select.value === 'custom' ? 'block' : 'none';
            customMacro.style.display = select.value === 'custom' ? 'block' : 'none';
        }
        const search = document.getElementById('foodSearch');
        if (search) {
            search.addEventListener('input', function () {
                const q = this.value.toLowerCase().trim();
                document.querySelectorAll('.js-food-row').forEach(function (row) {
                    const n = row.getAttribute('data-name') || '';
                    row.style.display = (!q || n.indexOf(q) !== -1) ? '' : 'none';
                });
            });
        }
        const batchForm = document.getElementById('batchForm');
        if (batchForm) {
            batchForm.addEventListener('submit', function (e) {
                const any = this.querySelector('.food-pick-row input[type="checkbox"]:checked');
                if (!any) {
                    e.preventDefault();
                    alert('Select at least one food.');
                }
            });
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const weekCtx = document.getElementById('weekChart');
        if (weekCtx && typeof Chart !== 'undefined') {
            new Chart(weekCtx, {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($weekLabels); ?>,
                    datasets: [{
                        label: 'Calories',
                        data: <?php echo json_encode($weekValues); ?>,
                        borderColor: '#0d9488',
                        backgroundColor: 'rgba(13,148,136,.12)',
                        borderWidth: 3,
                        fill: true,
                        tension: 0.35,
                        pointRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true } }
                }
            });
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
