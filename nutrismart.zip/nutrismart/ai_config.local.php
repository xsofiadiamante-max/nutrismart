<?php
/**
 * Local secrets — not for version control. Copy from ai_config.local.example.php.
 * If you pasted a key in chat or shared this file, revoke the key at
 * https://platform.openai.com/api-keys and create a new one.
 */
return [
    'api_key' => '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',
    'model' => 'gpt-4o-mini',
    'api_base' => 'https://api.openai.com/v1',
];
