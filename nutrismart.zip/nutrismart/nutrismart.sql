-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2026 at 06:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nutrismart`
--

-- --------------------------------------------------------

--
-- Table structure for table `bmi_records`
--

CREATE TABLE `bmi_records` (
  `id` int(11) NOT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `height` decimal(5,2) DEFAULT NULL,
  `bmi` decimal(5,2) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `age` smallint(5) UNSIGNED DEFAULT NULL,
  `sex` varchar(16) DEFAULT NULL,
  `activity_level` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `bmi_records`
--

INSERT INTO `bmi_records` (`id`, `user_email`, `weight`, `height`, `bmi`, `category`, `recorded_at`, `age`, `sex`, `activity_level`) VALUES
(1, 'test@example.com', 70.00, 175.00, 22.90, 'Normal', '2026-03-10 08:37:13', NULL, NULL, NULL),
(2, 'test@example.com', 72.00, 175.00, 23.50, 'Normal', '2026-03-10 08:37:13', NULL, NULL, NULL),
(3, 'test@example.com', 69.00, 175.00, 22.50, 'Normal', '2026-03-10 08:37:13', NULL, NULL, NULL),
(4, 'jhon@gmail.com', 56.00, -5.80, 999.99, 'Obese', '2026-03-10 08:52:18', NULL, NULL, NULL),
(5, 'jhon@gmail.com', 56.00, -5.60, 999.99, 'Obese', '2026-03-10 08:53:40', NULL, NULL, NULL),
(6, 'jhon@gmail.com', 58.00, -5.60, 999.99, 'Obese', '2026-03-10 13:49:21', NULL, NULL, NULL),
(7, 'jhon@gmail.com', 58.00, -5.60, 999.99, 'Obese', '2026-03-10 13:49:32', NULL, NULL, NULL),
(8, 'kissy@gmail.com', 38.00, 51.00, 146.10, 'Obese', '2026-03-11 05:14:46', NULL, NULL, NULL),
(9, 'kissy@gmail.com', 38.00, 168.70, 13.35, 'Underweight', '2026-03-11 05:15:28', NULL, NULL, NULL),
(10, 'kissy@gmail.com', 38.00, 174.60, 12.47, 'Underweight', '2026-03-11 05:16:28', NULL, NULL, NULL),
(11, 'kristina@gmail.com', 56.00, 174.60, 18.37, 'Underweight', '2026-03-13 05:53:13', NULL, NULL, NULL),
(12, 'jhon@gmail.com', 48.00, 174.60, 15.75, 'Underweight', '2026-03-13 09:57:10', NULL, NULL, NULL),
(13, 'admin@gmail.com', 50.00, 153.00, 21.36, 'Normal', '2026-03-21 14:21:00', NULL, NULL, NULL),
(14, 'kalvin@gmail.com', 55.00, 151.00, 24.12, 'Normal', '2026-03-23 00:11:18', NULL, NULL, NULL),
(15, 'kalvin@gmail.com', 55.00, 151.00, 24.12, 'Normal', '2026-03-23 00:12:01', NULL, NULL, NULL),
(16, 'admin@gmail.com', 67.00, 159.00, 26.50, 'Overweight', '2026-03-29 03:38:56', NULL, NULL, NULL),
(17, 'jhon1233@GMAIL.COM', 67.00, 159.00, 26.50, 'Overweight', '2026-04-05 23:58:45', NULL, NULL, NULL),
(18, 'jhon1233@GMAIL.COM', 67.00, 159.00, 26.50, 'Overweight', '2026-04-05 23:59:15', NULL, NULL, NULL),
(19, 'jhon1233@GMAIL.COM', 67.00, 159.00, 26.50, 'Overweight', '2026-04-05 23:59:20', NULL, NULL, NULL),
(20, 'jhon1233@GMAIL.COM', 67.00, 159.00, 26.50, 'Overweight', '2026-04-05 23:59:29', NULL, NULL, NULL),
(21, 'admin@gmail.com', 56.00, 59.00, 160.87, 'Obese', '2026-04-06 04:18:08', NULL, NULL, NULL),
(22, 'admin@gmail.com', 56.00, 59.00, 160.87, 'Obese', '2026-04-06 04:40:54', NULL, NULL, NULL),
(23, 'admin@gmail.com', 56.00, 59.00, 160.87, 'Obese', '2026-04-06 04:50:23', NULL, NULL, NULL),
(24, 'admin@gmail.com', 56.00, 59.00, 160.87, 'Obese', '2026-04-06 04:50:41', NULL, NULL, NULL),
(25, 'admin@gmail.com', 56.00, 59.00, 160.87, 'Obese', '2026-04-06 04:58:24', NULL, NULL, NULL),
(26, 'admin@gmail.com', 56.00, 168.00, 19.84, 'Normal', '2026-04-06 05:12:49', 25, 'male', 'moderate'),
(27, 'admin@gmail.com', 56.00, 168.00, 19.84, 'Normal', '2026-04-06 05:51:06', 25, 'male', 'very_active'),
(28, 'admin@gmail.com', 65.00, 168.00, 23.03, 'Normal', '2026-04-06 06:03:43', 25, 'male', 'very_active'),
(29, 'admin@gmail.com', 56.00, 168.00, 19.84, 'Normal', '2026-04-06 06:20:21', 22, 'female', 'sedentary'),
(30, 'admin@gmail.com', 56.00, 168.00, 19.84, 'Normal', '2026-04-06 06:20:24', 22, 'female', 'sedentary'),
(31, 'admin@gmail.com', 56.00, 181.00, 17.09, 'Underweight', '2026-04-06 10:14:41', 20, 'male', 'moderate'),
(32, 'admin@gmail.com', 56.00, 181.00, 17.09, 'Underweight', '2026-04-06 10:15:43', 20, 'male', 'moderate'),
(33, 'admin@gmail.com', 56.00, 181.00, 17.09, 'Underweight', '2026-04-06 10:48:27', 20, 'male', 'moderate'),
(34, 'admin@gmail.com', 56.00, 181.00, 17.09, 'Underweight', '2026-04-06 11:25:40', 20, 'female', 'moderate'),
(35, 'admin@gmail.com', 56.10, 181.00, 17.12, 'Underweight', '2026-04-06 11:37:42', 25, 'female', 'light'),
(36, 'admin@gmail.com', 50.00, 179.00, 15.61, 'Underweight', '2026-04-07 00:58:37', 20, 'male', 'moderate'),
(37, 'blaire@gmail.com', 50.00, 155.00, 20.81, 'Normal', '2026-04-07 06:24:21', 20, 'female', 'moderate'),
(38, 'blaire@gmail.com', 50.00, 154.00, 21.08, 'Normal', '2026-04-07 07:06:50', 20, 'female', 'sedentary'),
(39, 'admin@gmail.com', 50.00, 181.00, 15.26, 'Underweight', '2026-04-13 07:26:04', 20, 'male', 'moderate'),
(40, 'admin@gmail.com', 50.00, 181.00, 15.26, 'Underweight', '2026-04-13 07:27:11', 20, 'male', 'moderate'),
(41, 'admin@gmail.com', 55.00, 169.00, 19.26, 'Normal', '2026-04-21 10:43:41', 20, 'female', 'light'),
(42, 'doe@gmail.com', 58.00, 169.00, 20.31, 'Normal', '2026-04-21 11:53:50', 20, 'male', 'light');

-- --------------------------------------------------------

--
-- Table structure for table `calorie_log`
--

CREATE TABLE `calorie_log` (
  `id` int(11) NOT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `food` varchar(100) DEFAULT NULL,
  `meal_type` varchar(20) DEFAULT 'snack',
  `calories` int(11) DEFAULT NULL,
  `servings` decimal(6,2) DEFAULT 1.00,
  `notes` varchar(255) DEFAULT NULL,
  `protein_g` decimal(8,2) DEFAULT 0.00,
  `carbs_g` decimal(8,2) DEFAULT 0.00,
  `fat_g` decimal(8,2) DEFAULT 0.00,
  `logged_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `calorie_log`
--

INSERT INTO `calorie_log` (`id`, `user_email`, `food`, `meal_type`, `calories`, `servings`, `notes`, `protein_g`, `carbs_g`, `fat_g`, `logged_at`) VALUES
(1, 'test@example.com', 'Apple', 'snack', 95, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:37:13'),
(2, 'test@example.com', 'Grilled Chicken Breast', 'snack', 165, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:37:13'),
(3, 'test@example.com', 'Brown Rice', 'snack', 216, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:37:13'),
(4, 'test@example.com', '', 'snack', 0, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:38:33'),
(5, 'jhon@gmail.com', '', 'snack', 0, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:53:00'),
(6, 'jhon@gmail.com', 'Orange', 'snack', 62, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:53:08'),
(7, 'jhon@gmail.com', '', 'snack', 0, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:53:10'),
(8, 'jhon@gmail.com', 'Avocado', 'snack', 234, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:53:13'),
(9, 'jhon@gmail.com', 'Salad Bowl', 'snack', 120, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-10 08:53:19'),
(10, 'kissy@gmail.com', '', 'snack', 0, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-11 05:17:19'),
(11, 'kristina@gmail.com', 'Salad Bowl', 'snack', 120, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-13 05:55:06'),
(12, 'kalvin@gmail.com', 'Broccoli', 'snack', 55, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-23 00:03:30'),
(13, 'admin@gmail.com', 'Brown Rice', 'snack', 216, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-29 03:52:39'),
(14, 'admin@gmail.com', 'Sweet Potato', 'snack', 103, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-29 03:52:45'),
(15, 'admin@gmail.com', 'Salmon', 'snack', 367, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-29 03:52:52'),
(16, 'admin@gmail.com', 'Almonds (30g)', 'snack', 170, 1.00, NULL, 0.00, 0.00, 0.00, '2026-03-29 03:52:59'),
(17, 'admin@gmail.com', 'Avocado', 'snack', 234, 1.00, NULL, 0.00, 0.00, 0.00, '2026-04-06 04:41:23'),
(28, 'admin@gmail.com', 'Salmon with Sweet Potato', 'dinner', 500, 1.00, 'Added from meal planner template', 0.00, 0.00, 0.00, '2026-04-07 00:59:25'),
(29, 'admin@gmail.com', 'Custom', 'breakfast', 1000, 1.00, 'baboy', 0.00, 0.00, 0.00, '2026-04-07 01:01:39'),
(30, 'admin@gmail.com', 'baboy', 'breakfast', 1000, 1.00, 'for abs', 100.00, 100.00, 100.00, '2026-04-07 01:02:43'),
(31, 'admin@gmail.com', 'chart', 'lunch', 1600, 2.00, 'for abs', 0.00, 0.00, 0.00, '2026-04-07 01:04:09'),
(32, 'admin@gmail.com', 'chart', 'lunch', 1600, 2.00, 'for abs', 0.00, 0.00, 0.00, '2026-04-07 01:04:31'),
(33, 'kessy123@gmail.com', 'Apple', 'snack', 95, 1.00, NULL, 0.00, 0.00, 0.00, '2026-04-07 01:07:31'),
(34, 'kessy123@gmail.com', 'Avocado', 'snack', 234, 1.00, NULL, 0.00, 0.00, 0.00, '2026-04-07 01:07:31'),
(35, 'kessy123@gmail.com', 'adobo', 'lunch', 569, 1.00, 'for overall weight', 0.00, 0.00, 0.00, '2026-04-07 01:08:10'),
(36, 'doe@gmail.com', 'Scrambled Eggs with Whole Wheat Toast', 'breakfast', 300, 1.00, 'Added from meal planner template', 0.00, 0.00, 0.00, '2026-04-25 12:34:37'),
(37, 'doe@gmail.com', 'Quinoa Salad with Grilled Vegetables', 'lunch', 400, 1.00, 'Added from meal planner template', 0.00, 0.00, 0.00, '2026-04-25 12:34:43'),
(38, 'doe@gmail.com', 'Apple with Peanut Butter', 'snack', 150, 1.00, 'Added from meal planner template', 0.00, 0.00, 0.00, '2026-04-25 12:34:46');

-- --------------------------------------------------------

--
-- Table structure for table `foods`
--

CREATE TABLE `foods` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `foods`
--

INSERT INTO `foods` (`id`, `name`, `calories`) VALUES
(1, 'Apple', 95),
(2, 'Banana', 105),
(3, 'Orange', 62),
(4, 'Grilled Chicken Breast', 165),
(5, 'Salad Bowl', 120),
(6, 'Brown Rice', 216),
(7, 'Broccoli', 55),
(8, 'Salmon', 367),
(9, 'Eggs (2)', 140),
(10, 'Oatmeal', 150),
(11, 'Greek Yogurt', 100),
(12, 'Almonds (30g)', 170),
(13, 'Whole Wheat Bread', 79),
(14, 'Avocado', 234),
(15, 'Sweet Potato', 103);

-- --------------------------------------------------------

--
-- Table structure for table `meal_plans`
--

CREATE TABLE `meal_plans` (
  `id` int(11) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `meal_time` varchar(50) DEFAULT NULL,
  `food` varchar(200) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `meal_plans`
--

INSERT INTO `meal_plans` (`id`, `category`, `meal_time`, `food`, `calories`) VALUES
(1, 'Underweight', 'Breakfast', 'Oatmeal with Banana and Almonds', 350),
(2, 'Underweight', 'Lunch', 'Grilled Chicken with Brown Rice', 450),
(3, 'Underweight', 'Dinner', 'Salmon with Sweet Potato', 500),
(4, 'Underweight', 'Snack', 'Greek Yogurt with Honey', 200),
(5, 'Normal', 'Breakfast', 'Scrambled Eggs with Whole Wheat Toast', 300),
(6, 'Normal', 'Lunch', 'Quinoa Salad with Grilled Vegetables', 400),
(7, 'Normal', 'Dinner', 'Baked Fish with Steamed Broccoli', 350),
(8, 'Normal', 'Snack', 'Apple with Peanut Butter', 150),
(9, 'Overweight', 'Breakfast', 'Smoothie Bowl with Berries', 250),
(10, 'Overweight', 'Lunch', 'Grilled Chicken Salad', 300),
(11, 'Overweight', 'Dinner', 'Vegetable Soup with Lean Protein', 280),
(12, 'Overweight', 'Snack', 'Carrot Sticks with Hummus', 120),
(13, 'Obese', 'Breakfast', 'Green Smoothie', 200),
(14, 'Obese', 'Lunch', 'Steamed Vegetables with Tofu', 250),
(15, 'Obese', 'Dinner', 'Grilled Fish with Salad', 220),
(16, 'Obese', 'Snack', 'Cucumber Slices', 30);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `daily_calorie_goal` int(11) DEFAULT 2000
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `daily_calorie_goal`) VALUES
(1, 'Test User', 'test@example.com', 'e10adc3949ba59abbe56e057f20f883e', '2026-03-10 08:37:13', 2000),
(2, 'John Doe', 'john@example.com', 'e10adc3949ba59abbe56e057f20f883e', '2026-03-10 08:37:13', 2000),
(3, 'jhon', 'jhon@gmail.com', 'd1162401a3f52f9c2c66e365f0a11856', '2026-03-10 08:39:33', 2000),
(4, 'kissy', 'kissy@gmail.com', 'ebf1c7293c1d15b70b2c7f07d3308964', '2026-03-11 05:12:36', 2000),
(5, 'dias@gmail.com', 'dias@gmail.com', 'd1162401a3f52f9c2c66e365f0a11856', '2026-03-11 05:13:47', 2000),
(6, 'kristina', 'kristina@gmail.com', '19ad5c2a1f2c13a53b2ade325a0631e0', '2026-03-13 05:52:34', 2000),
(7, 'kl', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', '2026-03-21 14:20:33', 2000),
(8, 'kalvin', 'kalvin@gmail.com', 'c0012f16a92694eb4fe74e70e5aee78e', '2026-03-22 23:51:33', 2000),
(9, 'JHON', 'jhon1233@GMAIL.COM', 'f8894d2c589ac837633c4ade8665980a', '2026-04-05 23:58:07', 2000),
(10, 'nicole', 'nicole123@gmail.com', 'd1162401a3f52f9c2c66e365f0a11856', '2026-04-06 11:41:27', 2000),
(11, 'kessy', 'kessy123@gmail.com', 'd1162401a3f52f9c2c66e365f0a11856', '2026-04-07 01:06:23', 1800),
(12, 'blaire', 'blaire@gmail.com', 'a1ce630c85b75e85ad4ef59f20b36b8c', '2026-04-07 06:16:24', 2000),
(13, 'John Doe', 'doe@gmail.com', '02e78ed594da18bc0d05ca74d721d5fe', '2026-04-21 11:49:36', 2000),
(14, 'cassie', 'cassiebuenn@gmail.com', 'c7bcfcdc2816040794d451f437db8229', '2026-04-23 03:55:00', 2000),
(15, 'Jogn', 'a@gmail.com', 'd29c7966a6a00140dec2a0c4c4fe4111', '2026-04-25 12:34:03', 2000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bmi_records`
--
ALTER TABLE `bmi_records`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `calorie_log`
--
ALTER TABLE `calorie_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `foods`
--
ALTER TABLE `foods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meal_plans`
--
ALTER TABLE `meal_plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bmi_records`
--
ALTER TABLE `bmi_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `calorie_log`
--
ALTER TABLE `calorie_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `foods`
--
ALTER TABLE `foods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `meal_plans`
--
ALTER TABLE `meal_plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
